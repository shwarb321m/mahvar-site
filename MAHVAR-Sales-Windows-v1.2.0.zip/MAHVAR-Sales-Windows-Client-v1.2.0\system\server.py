from __future__ import annotations

import json
import mimetypes
import os
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.parse
import webbrowser
from dataclasses import asdict, is_dataclass
from datetime import date, datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from database import Database, app_data_dir
from license_service import LicenseService
from reports import (
    build_report_html,
    build_whatsapp_summary,
    create_backup,
    export_report,
    export_sales_csv,
    open_path,
    open_whatsapp,
    restore_backup,
    show_in_folder,
    validate_backup,
)

APP_VERSION = "3.3.0"
DEFAULT_PORT = 8765
UI_DIR = Path(__file__).resolve().parent / "ui"


def fmt_money(value: Any) -> str:
    """رقم بفواصل الآلاف، مع كسور عشرية فقط عند وجودها (12.5 تبقى 12.5 و 1200 تبقى 1,200)."""
    try:
        number = round(float(value or 0), 2) + 0.0
    except (TypeError, ValueError):
        number = 0.0
    text = f"{number:,.2f}".rstrip("0").rstrip(".")
    return text


def resource_path(relative: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / relative


def rows(items: Any) -> list[dict[str, Any]]:
    return [dict(x) for x in items]


def jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {k: jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [jsonable(v) for v in value]
    return value


def local_ip() -> str:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return "127.0.0.1"


def find_edge() -> Path | None:
    candidates = [
        Path(os.getenv("PROGRAMFILES(X86)", "")) / "Microsoft/Edge/Application/msedge.exe",
        Path(os.getenv("PROGRAMFILES", "")) / "Microsoft/Edge/Application/msedge.exe",
        Path(os.getenv("LOCALAPPDATA", "")) / "Microsoft/Edge/Application/msedge.exe",
    ]
    return next((p for p in candidates if str(p) and p.exists()), None)


class ScannerBus:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.events: list[dict[str, Any]] = []
        self.counter = 0

    def push(self, payload: dict[str, Any], product: dict[str, Any] | None) -> dict[str, Any]:
        with self.lock:
            self.counter += 1
            event = {
                "id": self.counter,
                "barcode": str(payload.get("barcode", "")).strip(),
                "mode": str(payload.get("mode", "sale")),
                "device_name": str(payload.get("device_name", "هاتف")),
                "received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "product": product,
            }
            self.events.append(event)
            self.events = self.events[-100:]
            return event

    def after(self, event_id: int) -> list[dict[str, Any]]:
        with self.lock:
            return [e for e in self.events if int(e["id"]) > event_id]


class AppState:
    def __init__(self, port: int) -> None:
        self.db = Database()
        self.license = LicenseService(app_data_dir(), APP_VERSION)
        threading.Thread(target=self.license.sync_trial, daemon=True).start()
        self.port = port
        self.ip = local_ip()
        self.scanner = ScannerBus()
        token = self.db.get_setting("scanner_token", "")
        if not token:
            token = f"{secrets.randbelow(1_000_000):06d}"
            self.db.set_setting("scanner_token", token)
        self.scanner_token = token

    def reset_token(self) -> str:
        self.scanner_token = f"{secrets.randbelow(1_000_000):06d}"
        self.db.set_setting("scanner_token", self.scanner_token)
        return self.scanner_token


STATE: AppState


class Handler(BaseHTTPRequestHandler):
    server_version = "MAHVARSales/3.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        log = app_data_dir() / "server.log"
        try:
            with log.open("a", encoding="utf-8") as f:
                f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {self.address_string()} {fmt % args}\n")
        except OSError:
            pass

    @property
    def is_local(self) -> bool:
        return self.client_address[0] in {"127.0.0.1", "::1", "localhost"}

    def _json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(jsonable(data), ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, message: str, status: int = 400, detail: str = "") -> None:
        self._json({"ok": False, "error": message, "detail": detail}, status)

    def _read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        if not raw:
            return {}
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("البيانات المرسلة غير صالحة") from exc
        if not isinstance(parsed, dict):
            raise ValueError("صيغة الطلب غير صحيحة")
        return parsed

    def _query(self) -> dict[str, str]:
        parsed = urllib.parse.urlparse(self.path)
        return {k: v[-1] for k, v in urllib.parse.parse_qs(parsed.query).items()}

    def _route(self) -> str:
        return urllib.parse.urlparse(self.path).path.rstrip("/") or "/"

    def _require_local(self) -> bool:
        if not self.is_local:
            self._error("هذا المسار متاح من جهاز المحاسبة فقط", 403)
            return False
        return True

    def _serve_static(self, route: str) -> None:
        root = resource_path("ui")
        rel = "index.html" if route in {"/", ""} else route.lstrip("/")
        candidate = (root / rel).resolve()
        if root.resolve() not in candidate.parents and candidate != root.resolve():
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        if not candidate.exists() or not candidate.is_file():
            # SPA fallback
            candidate = root / "index.html"
        data = candidate.read_bytes()
        mime = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
        if candidate.suffix == ".js":
            mime = "application/javascript"
        self.send_response(200)
        self.send_header("Content-Type", f"{mime}; charset=utf-8" if mime.startswith("text/") or "javascript" in mime else mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:  # noqa: N802
        route = self._route()
        try:
            if route.startswith("/api/"):
                self._handle_get_api(route)
            elif route.startswith("/invoice/"):
                if not self._require_local():
                    return
                self._invoice_html(int(route.rsplit("/", 1)[1]))
            else:
                self._serve_static(route)
        except Exception as exc:  # noqa: BLE001
            self._handle_exception(exc)

    def do_POST(self) -> None:  # noqa: N802
        route = self._route()
        try:
            if route == "/api/scanner/push":
                self._scanner_push()
                return
            if route == "/api/scanner/ping":
                self._scanner_ping()
                return
            if not self._require_local():
                return
            self._handle_post_api(route)
        except Exception as exc:  # noqa: BLE001
            self._handle_exception(exc)

    def _handle_exception(self, exc: Exception) -> None:
        detail = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        try:
            (app_data_dir() / "error.log").write_text(detail, encoding="utf-8")
        except OSError:
            pass
        status = 400 if isinstance(exc, (ValueError, KeyError)) else 500
        self._error(str(exc) or "حدث خطأ غير متوقع", status, detail if status == 500 else "")

    def _handle_get_api(self, route: str) -> None:
        if route == "/api/license/status":
            if not self._require_local():
                return
            self._json(STATE.license.status())
            return
        if route == "/api/scanner/info":
            if not self._require_local():
                return
            self._json({
                "ok": True,
                "ip": STATE.ip,
                "port": STATE.port,
                "token": STATE.scanner_token,
                "endpoint": f"http://{STATE.ip}:{STATE.port}",
            })
            return
        if route == "/api/scanner/poll":
            if not self._require_local():
                return
            after = int(self._query().get("after", "0") or 0)
            self._json({"ok": True, "events": STATE.scanner.after(after)})
            return
        if not self._require_local():
            return
        q = self._query()
        db = STATE.db
        if route == "/api/bootstrap":
            self._json({
                "ok": True,
                "version": APP_VERSION,
                "license": STATE.license.status(),
                "settings": db.all_settings(),
                "dashboard": db.dashboard_stats(),
                "products": rows(db.list_products()),
                "customers": rows(db.list_customers()),
                "suppliers": rows(db.list_suppliers()),
                "scanner": {"ip": STATE.ip, "port": STATE.port, "token": STATE.scanner_token},
                "rate_log": rows(db.list_rate_log()),
            })
        elif route == "/api/dashboard":
            low = [dict(p) for p in db.list_products() if float(p["quantity"]) <= float(p["minimum_stock"])]
            self._json({"ok": True, "stats": db.dashboard_stats(), "low_stock": low})
        elif route == "/api/products":
            self._json({"ok": True, "items": rows(db.list_products(q.get("search", "")))})
        elif route.startswith("/api/products/barcode/"):
            barcode = urllib.parse.unquote(route.split("/barcode/", 1)[1])
            product = db.get_product_by_barcode(barcode)
            self._json({"ok": True, "product": dict(product) if product else None})
        elif route == "/api/customers":
            self._json({"ok": True, "items": rows(db.list_customers(q.get("search", "")))})
        elif route == "/api/suppliers":
            self._json({"ok": True, "items": rows(db.list_suppliers(q.get("search", "")))})
        elif route == "/api/sales":
            self._json({"ok": True, "items": rows(db.list_sales(q.get("from"), q.get("to"), int(q.get("limit", "500"))))})
        elif route.startswith("/api/sales/") and route.endswith("/items"):
            sale_id = int(route.split("/")[3])
            self._json({"ok": True, "items": rows(db.sale_items(sale_id))})
        elif route == "/api/purchases":
            self._json({"ok": True, "items": rows(db.list_purchases(q.get("from"), q.get("to"), int(q.get("limit", "500"))))})
        elif route.startswith("/api/purchases/") and route.endswith("/items"):
            purchase_id = int(route.split("/")[3])
            self._json({"ok": True, "items": rows(db.purchase_items(purchase_id))})
        elif route == "/api/stock/movements":
            self._json({"ok": True, "items": rows(db.list_stock_movements(int(q.get("limit", "1000"))))})
        elif route.startswith("/api/customers/") and route.endswith("/statement"):
            party_id = int(route.split("/")[3])
            self._json({"ok": True, "data": db.customer_statement(party_id)})
        elif route.startswith("/api/suppliers/") and route.endswith("/statement"):
            party_id = int(route.split("/")[3])
            self._json({"ok": True, "data": db.supplier_statement(party_id)})
        elif route == "/api/reports/data":
            d1 = q.get("from", date.today().isoformat())
            d2 = q.get("to", d1)
            self._json({"ok": True, "data": db.report_data(d1, d2)})
        elif route == "/api/settings":
            self._json({"ok": True, "settings": db.all_settings()})
        elif route == "/api/usd-rate":
            self._json({"ok": True, "rate": db.get_usd_rate(), "rounding": db.get_setting("price_rounding", "none"), "log": rows(db.list_rate_log())})
        else:
            self._error("المسار غير موجود", 404)

    def _handle_post_api(self, route: str) -> None:
        db = STATE.db
        if route == "/api/license/activate":
            data = self._read_json()
            self._json({"ok": True, "license": STATE.license.activate(str(data.get("code", "")))})
            return
        if route == "/api/license/open-whatsapp":
            webbrowser.open(STATE.license.whatsapp_url())
            self._json({"ok": True})
            return
        allowed_after_expiry = {"/api/backup/create", "/api/system/open-folder"}
        if not STATE.license.is_allowed() and route not in allowed_after_expiry and route != "/api/backup/restore":
            self._error("انتهت الفترة التجريبية. فعّل النسخة لمتابعة الاستخدام", 402)
            return
        if route == "/api/backup/restore":
            length = int(self.headers.get("Content-Length", "0") or 0)
            if length <= 0 or length > 1024 * 1024 * 500:
                raise ValueError("ملف النسخة غير صالح أو كبير جداً")
            filename = Path(urllib.parse.unquote(self.headers.get("X-Filename", "backup.zip"))).name
            suffix = Path(filename).suffix or ".zip"
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                remaining = length
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    tmp.write(chunk)
                    remaining -= len(chunk)
                temp_path = Path(tmp.name)
            try:
                meta = validate_backup(temp_path)
                safety = restore_backup(db, temp_path)
                self._json({"ok": True, "message": "تمت الاستعادة بنجاح", "meta": meta, "safety_backup": str(safety)})
            finally:
                temp_path.unlink(missing_ok=True)
            return

        data = self._read_json()
        if route == "/api/products/save":
            product_id = data.get("id")
            saved = db.save_product(data, int(product_id) if product_id else None)
            self._json({"ok": True, "id": saved})
        elif route.startswith("/api/products/") and route.endswith("/deactivate"):
            db.deactivate_product(int(route.split("/")[3]))
            self._json({"ok": True})
        elif route == "/api/sales/create":
            result = db.create_sale(
                list(data.get("items") or []),
                int(data["customer_id"]) if data.get("customer_id") else None,
                float(data.get("discount") or 0),
                float(data.get("paid_amount") or 0),
                str(data.get("note", "")),
            )
            self._json({"ok": True, "sale": asdict(result)})
        elif route.startswith("/api/sales/") and route.endswith("/void"):
            db.void_sale(int(route.split("/")[3]), str(data.get("reason", "إلغاء من النظام")))
            self._json({"ok": True})
        elif route == "/api/purchases/create":
            result = db.create_purchase(
                list(data.get("items") or []),
                int(data["supplier_id"]) if data.get("supplier_id") else None,
                float(data.get("paid_amount") or 0),
                str(data.get("note", "")),
            )
            self._json({"ok": True, "purchase": asdict(result)})
        elif route.startswith("/api/purchases/") and route.endswith("/void"):
            db.void_purchase(int(route.split("/")[3]), str(data.get("reason", "إلغاء من النظام")))
            self._json({"ok": True})
        elif route in {"/api/customers/save", "/api/suppliers/save"}:
            kind = "customer" if "customers" in route else "supplier"
            party_id = data.get("id")
            if party_id:
                db.update_party(kind, int(party_id), str(data.get("name", "")), str(data.get("phone", "")), str(data.get("address", "")), str(data.get("notes", "")))
                saved_id = int(party_id)
            else:
                saved_id = db.add_party(kind, str(data.get("name", "")), str(data.get("phone", "")), str(data.get("address", "")), str(data.get("notes", "")))
            self._json({"ok": True, "id": saved_id})
        elif route.startswith("/api/customers/") and route.endswith("/payments"):
            pid = int(route.split("/")[3])
            payment_id = db.record_payment("customer", pid, float(data.get("amount") or 0), str(data.get("note", "")))
            self._json({"ok": True, "id": payment_id})
        elif route.startswith("/api/suppliers/") and route.endswith("/payments"):
            pid = int(route.split("/")[3])
            payment_id = db.record_payment("supplier", pid, float(data.get("amount") or 0), str(data.get("note", "")))
            self._json({"ok": True, "id": payment_id})
        elif route == "/api/inventory/adjust":
            difference = db.inventory_adjust(int(data["product_id"]), float(data["counted_quantity"]), str(data.get("note", "")))
            self._json({"ok": True, "difference": difference})
        elif route == "/api/expenses/add":
            expense_id = db.add_expense(str(data.get("category", "عام")), float(data.get("amount") or 0), str(data.get("note", "")))
            self._json({"ok": True, "id": expense_id})
        elif route == "/api/settings/save":
            for key in ("store_name", "owner_phone", "currency", "operator_name"):
                if key in data:
                    db.set_setting(key, str(data[key]))
            self._json({"ok": True, "settings": db.all_settings()})
        elif route == "/api/usd-rate/preview":
            self._json({"ok": True, "preview": db.preview_rate_change(float(data.get("rate") or 0), str(data.get("rounding", "none")))})
        elif route == "/api/usd-rate/apply":
            result = db.apply_rate_change(float(data.get("rate") or 0), str(data.get("rounding", "none")))
            self._json({"ok": True, "result": result, "settings": db.all_settings(), "log": rows(db.list_rate_log())})
        elif route == "/api/scanner/token/reset":
            self._json({"ok": True, "token": STATE.reset_token()})
        elif route == "/api/reports/export":
            d1 = str(data.get("from", date.today().isoformat()))
            d2 = str(data.get("to", d1))
            report_type = str(data.get("type", "full"))
            paths = export_report(db, d1, d2, report_type)
            preferred = paths.get("pdf") or paths.get("html")
            if preferred:
                show_in_folder(Path(preferred))
                open_path(Path(preferred))
            self._json({"ok": True, "paths": paths})
        elif route == "/api/reports/csv":
            path = export_sales_csv(db, str(data.get("from")), str(data.get("to")))
            show_in_folder(path)
            self._json({"ok": True, "path": str(path)})
        elif route == "/api/reports/whatsapp":
            d1 = str(data.get("from", date.today().isoformat()))
            d2 = str(data.get("to", d1))
            report_type = str(data.get("type", "full"))
            phone = str(data.get("phone") or db.get_setting("owner_phone", ""))
            text = build_whatsapp_summary(db, d1, d2, report_type)
            paths = export_report(db, d1, d2, report_type)
            preferred = paths.get("pdf") or paths.get("html")
            if preferred:
                show_in_folder(Path(preferred))
            open_whatsapp(phone, text)
            self._json({"ok": True, "path": str(preferred) if preferred else "", "message": text})
        elif route == "/api/backup/create":
            path = create_backup(db)
            show_in_folder(path)
            self._json({"ok": True, "path": str(path)})
        elif route == "/api/system/open-folder":
            target = str(data.get("target", "reports"))
            from reports import backup_folder, report_folder
            path = backup_folder() if target == "backups" else report_folder()
            open_path(path)
            self._json({"ok": True, "path": str(path)})
        else:
            self._error("المسار غير موجود", 404)

    def _scanner_auth(self, data: dict[str, Any]) -> bool:
        token = str(self.headers.get("X-Scanner-Token", "") or data.get("token", "")).strip()
        return secrets.compare_digest(token, STATE.scanner_token)

    def _scanner_ping(self) -> None:
        data = self._read_json()
        if not self._scanner_auth(data):
            self._error("رمز الربط غير صحيح", 401)
            return
        self._json({"ok": True, "store_name": STATE.db.get_setting("store_name", "MAHVAR للمبيعات"), "version": APP_VERSION})

    def _scanner_push(self) -> None:
        data = self._read_json()
        if not self._scanner_auth(data):
            self._error("رمز الربط غير صحيح", 401)
            return
        barcode = str(data.get("barcode", "")).strip()
        if not barcode:
            raise ValueError("الباركود فارغ")
        product_row = STATE.db.get_product_by_barcode(barcode)
        product = dict(product_row) if product_row else None
        event = STATE.scanner.push(data, product)
        self._json({"ok": True, "event_id": event["id"], "product": product, "message": product["name"] if product else "منتج غير موجود"})

    def _invoice_html(self, sale_id: int) -> None:
        sales = [dict(x) for x in STATE.db.list_sales(limit=5000) if int(x["id"]) == sale_id]
        if not sales:
            self.send_error(404)
            return
        sale = sales[0]
        items = rows(STATE.db.sale_items(sale_id))
        settings = STATE.db.all_settings()
        currency = settings.get("currency", "ل.س")
        lines = "".join(
            f"<tr><td>{i + 1}</td><td>{self._esc(x['product_name'])}</td><td>{x['quantity']:g}</td><td>{fmt_money(x['unit_price'])}</td><td>{fmt_money(x['line_total'])}</td></tr>"
            for i, x in enumerate(items)
        )
        content = f"""<!doctype html><html lang='ar' dir='rtl'><head><meta charset='utf-8'><title>{self._esc(sale['invoice_no'])}</title><style>
        @page{{size:80mm auto;margin:5mm}}body{{font-family:Tahoma,Arial;margin:0;color:#111}}.receipt{{width:72mm;margin:auto}}h1{{font-size:20px;text-align:center;margin:4px}}.meta{{text-align:center;font-size:12px;border-bottom:1px dashed #555;padding:8px}}table{{width:100%;border-collapse:collapse;font-size:11px;margin-top:8px}}th,td{{padding:5px 2px;border-bottom:1px solid #ddd;text-align:center}}.totals{{font-size:13px;margin-top:8px}}.row{{display:flex;justify-content:space-between;padding:3px 0}}.grand{{font-size:17px;font-weight:bold;border-top:2px solid #111;margin-top:4px;padding-top:6px}}footer{{text-align:center;margin-top:12px;font-size:11px}}@media print{{button{{display:none}}}}</style></head>
        <body><div class='receipt'><h1>{self._esc(settings.get('store_name','MAHVAR للمبيعات'))}</h1><div class='meta'>فاتورة رقم {self._esc(sale['invoice_no'])}<br>{self._esc(sale['created_at'])}<br>العميل: {self._esc(sale['customer_name'])}</div><table><thead><tr><th>#</th><th>الصنف</th><th>ك</th><th>السعر</th><th>المجموع</th></tr></thead><tbody>{lines}</tbody></table><div class='totals'><div class='row'><span>قبل الخصم</span><b>{fmt_money(sale['subtotal'])} {currency}</b></div><div class='row'><span>الخصم</span><b>{fmt_money(sale['discount'])} {currency}</b></div><div class='row grand'><span>الإجمالي</span><b>{fmt_money(sale['total'])} {currency}</b></div><div class='row'><span>المدفوع</span><b>{fmt_money(sale['paid_amount'])} {currency}</b></div><div class='row'><span>المتبقي</span><b>{fmt_money(sale['debt_amount'])} {currency}</b></div></div><footer>شكراً لزيارتكم<br><button onclick='print()'>طباعة</button></footer></div><script>setTimeout(()=>window.print(),350)</script></body></html>"""
        body = content.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    @staticmethod
    def _esc(value: Any) -> str:
        import html
        return html.escape(str(value or ""))


def choose_port(start: int = DEFAULT_PORT) -> int:
    for port in range(start, start + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            try:
                sock.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("تعذر إيجاد منفذ متاح لتشغيل التطبيق")


def open_app_window(url: str) -> subprocess.Popen[Any] | None:
    edge = find_edge()
    if edge:
        profile = app_data_dir() / "edge_profile"
        profile.mkdir(parents=True, exist_ok=True)
        return subprocess.Popen([
            str(edge),
            f"--app={url}",
            f"--user-data-dir={profile}",
            "--start-maximized",
            "--disable-features=msEdgeSidebarV2",
        ])
    webbrowser.open(url)
    return None


def main() -> None:
    global STATE
    port = choose_port()
    STATE = AppState(port)
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    url = f"http://127.0.0.1:{port}"
    process = open_app_window(url)
    try:
        if process:
            process.wait()
        else:
            print(f"MAHVAR للمبيعات يعمل على {url}")
            print("أغلق هذه النافذة لإيقاف البرنامج.")
            while True:
                time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            if STATE.db.get_setting("last_backup_date", "") != date.today().isoformat():
                create_backup(STATE.db)
        except Exception:
            pass
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
