'use strict';

const state = {
  settings: {}, dashboard: {}, products: [], customers: [], suppliers: [],
  saleCart: new Map(), purchaseCart: new Map(), paymentMode: 'cash',
  reportType: 'full', lastScannerEvent: 0, inventoryProduct: null,
  recordsMode: 'sales', license: null, rateLog: [],
};

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const today = () => new Date().toISOString().slice(0, 10);
const monthStart = () => `${today().slice(0, 8)}01`;
const num = v => Number(v || 0);
const esc = v => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const fmtQty = v => Number(v || 0).toLocaleString('ar', {maximumFractionDigits: 3});
const money = v => `${Number(v || 0).toLocaleString('ar', {maximumFractionDigits: 2})} ${state.settings.currency || 'ل.س'}`;
const fmtUsd = v => `$${Number(v || 0).toLocaleString('en-US', {maximumFractionDigits: 4})}`;
const ROUNDING_STEPS = {none:0, '0.5':0.5, '1':1, '5':5, '10':10, '50':50, '100':100};
const ROUNDING_LABELS = {none:'بلا تقريب', '0.5':'لأقرب نصف ليرة', '1':'لأقرب ليرة', '5':'لأقرب 5', '10':'لأقرب 10', '50':'لأقرب 50', '100':'لأقرب 100'};
const usdRate = () => Math.max(0, num(state.settings.usd_rate));
function roundPrice(value, rounding = state.settings.price_rounding || 'none') {
  const step = ROUNDING_STEPS[rounding] || 0; value = Math.max(0, num(value));
  if (!step) return Math.round(value * 100) / 100;
  const rounded = Math.round(Math.floor(value / step + 0.5 + 1e-9) * step * 100) / 100;
  return rounded > 0 || value <= 0 ? rounded : Math.round(value * 100) / 100;
}
const isLinked = p => p && p.usd_linked !== 0 && p.usd_linked !== '0';

async function api(path, options = {}) {
  const config = {...options};
  config.headers = {...(options.headers || {})};
  if (config.body && !(config.body instanceof Blob) && !(config.body instanceof ArrayBuffer)) {
    config.headers['Content-Type'] = 'application/json';
    if (typeof config.body !== 'string') config.body = JSON.stringify(config.body);
  }
  const response = await fetch(path, config);
  let data;
  try { data = await response.json(); } catch { data = {ok: false, error: 'رد غير صالح من البرنامج'}; }
  if (!response.ok || data.ok === false) throw new Error(data.error || `خطأ ${response.status}`);
  return data;
}

function loading(show = true) { $('#loading').classList.toggle('hidden', !show); }
function toast(message, type = 'success', ms = 3200) {
  const el = document.createElement('div'); el.className = `toast ${type}`;
  el.innerHTML = `<span>${type === 'error' ? '!' : '✓'}</span><div>${esc(message)}</div>`;
  $('#toastRoot').append(el); setTimeout(() => el.remove(), ms);
}
function confirmAction(message) { return window.confirm(message); }

function formatRemaining(seconds){
  seconds=Math.max(0,Number(seconds||0));
  const d=Math.floor(seconds/86400),h=Math.floor((seconds%86400)/3600),m=Math.floor((seconds%3600)/60);
  return d>0?`${d} يوم و${h} ساعة`:`${h} ساعة و${m} دقيقة`;
}
function renderLicense(status){
  state.license=status;
  const badge=$('#licenseBadgeText');
  if(badge) badge.textContent=status.activated?'النسخة مفعّلة':status.trial_active?`تجربة: ${formatRemaining(status.remaining_seconds)}`:'التفعيل مطلوب';
  const box=$('#licenseSettingsBox');
  if(box){
    $('#licenseStatusTitle').textContent=status.activated?'مفعّل دائماً':status.trial_active?'تجربة مجانية':'انتهت التجربة';
    $('#licenseStatusDetail').textContent=status.activated?`العميل: ${status.customer_name||'—'} · تاريخ التفعيل: ${status.activated_at||'—'}`:status.trial_active?`متبقي ${formatRemaining(status.remaining_seconds)} من أصل ${status.trial_days} أيام`:'أدخل كود تفعيل جديد للمتابعة';
    $('#licenseInstallId').textContent=status.install_id;
    $('#licenseApiWarning').classList.toggle('hidden',status.api_configured);
  }
  const overlay=$('#licenseOverlay');
  if(overlay) overlay.classList.toggle('hidden',!status.expired);
}
async function refreshLicense(){
  try{const r=await api('/api/license/status');renderLicense(r);return r}catch(e){toast(e.message,'error');return null}
}
async function activateLicense(inputId='licenseCode'){
  const input=$('#'+inputId);const code=(input?.value||'').trim();if(!code)return toast('اكتب كود التفعيل','error');
  loading(true);try{const r=await api('/api/license/activate',{method:'POST',body:{code}});renderLicense(r.license);toast('تم تفعيل النسخة بنجاح');if(input)input.value=''}catch(e){toast(e.message,'error',6000)}finally{loading(false)}
}
async function openActivationWhatsapp(){try{await api('/api/license/open-whatsapp',{method:'POST',body:{}})}catch(e){toast(e.message,'error')}}
function copyInstallId(){const v=state.license?.install_id||'';if(v)navigator.clipboard?.writeText(v).then(()=>toast('تم نسخ رمز التثبيت'))}

const pages = {
  dashboard: ['نظرة سريعة', 'أهم أرقام المحل اليوم'],
  cashier: ['فاتورة جديدة', 'بيع سريع بالباركود أو البحث'],
  inventory: ['المخزون والبضاعة', 'المنتجات والمشتريات والجرد ضمن مكان واحد'],
  customers: ['العملاء والديون', 'الأرصدة والدفعات وكشوف الحساب'],
  reports: ['التقارير والسجلات', 'تقارير واضحة للطباعة والإرسال'],
  settings: ['الإعدادات والنسخ', 'بيانات المحل وربط قارئ الهاتف والحماية'],
};
function goPage(name) {
  $$('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.page === name));
  $$('.page').forEach(p => p.classList.toggle('active', p.id === `page-${name}`));
  $('#pageTitle').textContent = pages[name][0]; $('#pageSubtitle').textContent = pages[name][1];
  if (name === 'cashier') setTimeout(() => $('#saleSearch').focus(), 80);
  if (name === 'reports') refreshReport();
}
function selectInventoryTab(name) {
  $$('#inventoryTabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  $$('.subpage[id^="inventory-"]').forEach(p => p.classList.toggle('active', p.id === `inventory-${name}`));
  $('#addProductBtn').style.display = name === 'products' ? '' : 'none';
  if (name === 'count') loadMovements();
}

function modal({title, body, wide = false, actions = ''}) {
  const root = $('#modalRoot');
  root.innerHTML = `<div class="modal-backdrop"><div class="modal ${wide ? 'wide' : ''}"><div class="modal-head"><h3>${esc(title)}</h3><button class="modal-close">×</button></div><div class="modal-body">${body}</div>${actions ? `<div class="modal-actions">${actions}</div>` : ''}</div></div>`;
  $('.modal-close', root).onclick = closeModal;
  $('.modal-backdrop', root).addEventListener('click', e => { if (e.target.classList.contains('modal-backdrop')) closeModal(); });
  return root;
}
function closeModal() { $('#modalRoot').innerHTML = ''; }

async function bootstrap() {
  loading(true);
  try {
    const data = await api('/api/bootstrap');
    state.settings = data.settings; state.dashboard = data.dashboard;
    if(data.license) renderLicense(data.license);
    state.products = data.products; state.customers = data.customers; state.suppliers = data.suppliers;
    state.rateLog = data.rate_log || [];
    $('#appVersion').textContent = data.version;
    renderAll();
    setupScannerInfo(data.scanner);
    refreshReportDates('today');
    await refreshRecords();
  } catch (e) { toast(e.message, 'error', 6000); }
  finally { loading(false); }
}
function renderAll() {
  renderUsdRate(); renderSettings(); renderDashboard(); renderProducts(); renderCustomers(); renderSuppliers(); fillSelects(); renderSaleCart(); renderPurchaseCart();
}
function renderSettings() {
  const s = state.settings;
  $('#brandName').textContent = s.store_name || 'MAHVAR'; $('#welcomeStore').textContent = s.store_name || 'MAHVAR للمبيعات';
  $('#settingStoreName').value = s.store_name || ''; $('#settingOwnerPhone').value = s.owner_phone || '';
  $('#settingCurrency').value = s.currency || 'ل.س'; $('#settingOperator').value = s.operator_name || '';
  $('#lastBackupDate').textContent = s.last_backup_date || 'لم تُنشأ نسخة بعد';
}
function renderDashboard() {
  const d = state.dashboard;
  $('#statSalesToday').textContent = money(d.sales_today); $('#statPaidToday').textContent = money(d.paid_today);
  $('#statCustomerDebt').textContent = money(d.customer_debt); $('#statShortages').textContent = Math.round(num(d.shortages));
  const low = state.products.filter(p => num(p.quantity) <= num(p.minimum_stock)).slice(0, 6);
  $('#dashboardLowStock').innerHTML = low.length ? low.map(p => `<div class="simple-item"><div><strong>${esc(p.name)}</strong><br><span>${esc(p.barcode)} · حد التنبيه ${fmtQty(p.minimum_stock)}</span></div><span class="qty-badge">باقي ${fmtQty(p.quantity)}</span></div>`).join('') : `<div class="empty-state" style="position:static;min-height:220px"><div class="empty-icon">✓</div><h3>المخزون جيد</h3><p>لا توجد نواقص حالياً.</p></div>`;
}

function renderProducts(filter = '') {
  const q = filter.trim().toLowerCase(); const items = state.products.filter(p => !q || p.name.toLowerCase().includes(q) || p.barcode.includes(q) || (p.category || '').toLowerCase().includes(q));
  $('#productsCount').textContent = `${items.length} منتج`;
  $('#productsBody').innerHTML = items.map(p => {
    const low = num(p.quantity) <= num(p.minimum_stock);
    return `<tr><td>${esc(p.barcode)}</td><td><strong>${esc(p.name)}</strong><br><small>${esc(p.unit)}</small></td><td>${esc(p.category || '—')}</td><td>${fmtQty(p.quantity)}</td><td>${money(p.sale_price)}${usdRate() ? (isLinked(p) ? `<small class="usd-sub">${p.usd_price != null ? fmtUsd(p.usd_price) : '—'}</small>` : `<small class="usd-sub fixed">ثابت بالليرة</small>`) : ''}</td><td><span class="badge ${low ? 'warning' : 'success'}">${low ? 'ناقص' : 'متوفر'}</span></td><td class="actions"><button class="icon-btn" data-edit-product="${p.id}" title="تعديل">✎</button><button class="icon-btn danger" data-delete-product="${p.id}" title="إيقاف">×</button></td></tr>`;
  }).join('') || `<tr><td colspan="7"><div class="empty-state" style="position:static;min-height:230px"><div class="empty-icon">⌕</div><h3>لا توجد منتجات</h3></div></td></tr>`;
  $$('[data-edit-product]').forEach(b => b.onclick = () => openProductModal(state.products.find(p => p.id == b.dataset.editProduct)));
  $$('[data-delete-product]').forEach(b => b.onclick = () => deactivateProduct(+b.dataset.deleteProduct));
  renderShortages();
}
function renderShortages() {
  const items = state.products.filter(p => num(p.quantity) <= num(p.minimum_stock)).sort((a,b)=>num(a.quantity)-num(b.quantity));
  $('#shortagesBody').innerHTML = items.map(p => `<tr><td>${esc(p.barcode)}</td><td><strong>${esc(p.name)}</strong></td><td>${fmtQty(p.quantity)}</td><td>${fmtQty(p.minimum_stock)}</td><td><span class="badge warning">${fmtQty(Math.max(0, num(p.minimum_stock)-num(p.quantity)))}</span></td></tr>`).join('') || `<tr><td colspan="5">لا توجد نواقص</td></tr>`;
}
function openProductModal(product = null) {
  const p = product || {barcode:'',name:'',category:'',purchase_price:0,sale_price:0,quantity:0,minimum_stock:0,unit:'قطعة',expiry_date:'',usd_linked:1,usd_price:null};
  const rate = usdRate(); const linked = isLinked(p);
  const usdStart = rate ? (p.usd_price != null ? Number(p.usd_price) : num(p.sale_price) / rate) : 0;
  const usdBox = `<div class="usd-product-box"><label class="check-row"><input id="mUsdLinked" type="checkbox" ${linked ? 'checked' : ''}><span>💵 مسعّر بالدولار (يتعدل سعره مع سعر الدولار)</span></label>${rate ? `<label class="field" id="mUsdField"><span>سعر البيع بالدولار</span><input id="mUsd" type="number" min="0" step="any" style="direction:ltr" value="${linked ? +usdStart.toFixed(4) : ''}"></label><small id="mUsdHint">سعر الدولار الحالي ${esc(String(rate))} — اكتب السعر بالدولار أو بالليرة والثاني بيتحسب لحاله</small>` : `<small>لسا ما انحط سعر الدولار. حطه من «الإعدادات والنسخ» وبعدين بيتحسب سعر المنتج بالدولار تلقائياً.</small>`}</div>`;
  modal({title: product ? 'تعديل المنتج' : 'إضافة منتج جديد', body: `<div class="form-grid two"><label class="field"><span>الباركود *</span><input id="mBarcode" value="${esc(p.barcode)}"></label><label class="field"><span>اسم المنتج *</span><input id="mName" value="${esc(p.name)}"></label><label class="field"><span>التصنيف</span><input id="mCategory" value="${esc(p.category)}"></label><label class="field"><span>الوحدة</span><input id="mUnit" value="${esc(p.unit)}"></label><label class="field"><span>سعر الشراء</span><input id="mPurchase" type="number" min="0" step="any" value="${p.purchase_price}"></label><label class="field"><span>سعر البيع (بالليرة)</span><input id="mSale" type="number" min="0" step="any" value="${p.sale_price}"></label><label class="field"><span>الكمية الحالية</span><input id="mQuantity" type="number" min="0" value="${p.quantity}"></label><label class="field"><span>حد التنبيه</span><input id="mMin" type="number" min="0" value="${p.minimum_stock}"></label><label class="field"><span>تاريخ الصلاحية</span><input id="mExpiry" type="date" value="${esc(p.expiry_date || '')}"></label>${usdBox}</div>`, actions:`<button class="btn primary" id="saveProductModal">حفظ المنتج</button><button class="btn ghost modal-close-action">إلغاء</button>`});
  $('.modal-close-action').onclick = closeModal;
  if (rate) {
    const syncLinked = () => { const on = $('#mUsdLinked').checked; $('#mUsd').disabled = !on; if (on && $('#mUsd').value === '') $('#mUsd').value = +(num($('#mSale').value) / rate).toFixed(4); };
    $('#mUsd').oninput = () => { if ($('#mUsdLinked').checked) $('#mSale').value = roundPrice(num($('#mUsd').value) * rate); };
    $('#mSale').oninput = () => { if ($('#mUsdLinked').checked) $('#mUsd').value = +(num($('#mSale').value) / rate).toFixed(4); };
    $('#mUsdLinked').onchange = syncLinked; syncLinked();
  }
  $('#saveProductModal').onclick = async () => {
    const usdLinked = $('#mUsdLinked').checked;
    const payload = {id: product?.id, barcode:$('#mBarcode').value.trim(), name:$('#mName').value.trim(), category:$('#mCategory').value.trim(), unit:$('#mUnit').value.trim(), purchase_price:num($('#mPurchase').value), sale_price:num($('#mSale').value), quantity:num($('#mQuantity').value), minimum_stock:num($('#mMin').value), expiry_date:$('#mExpiry').value, usd_linked: usdLinked ? 1 : 0, usd_price: (usdLinked && rate && $('#mUsd').value !== '') ? num($('#mUsd').value) : null};
    loading(true); try { await api('/api/products/save',{method:'POST',body:payload}); closeModal(); await reloadCore(); toast('تم حفظ المنتج'); } catch(e){toast(e.message,'error')} finally{loading(false)}
  };
  setTimeout(()=>$('#mBarcode').focus(),30);
}
async function deactivateProduct(id) { if(!confirmAction('هل تريد إيقاف هذا المنتج؟ سيبقى محفوظاً في الفواتير القديمة.'))return; try{await api(`/api/products/${id}/deactivate`,{method:'POST',body:{}});await reloadCore();toast('تم إيقاف المنتج')}catch(e){toast(e.message,'error')} }

function fillSelects() {
  const prodOptions = state.products.map(p => `<option value="${p.id}">${esc(p.name)} — ${esc(p.barcode)}</option>`).join('');
  $('#purchaseProduct').innerHTML = `<option value="">اختر المنتج</option>${prodOptions}`;
  const customerOptions = state.customers.map(c => `<option value="${c.id}">${esc(c.name)}${num(c.balance)>0?` — عليه ${money(c.balance)}`:''}</option>`).join('');
  $('#saleCustomer').innerHTML = `<option value="">اختر العميل</option>${customerOptions}`;
  const supplierOptions = state.suppliers.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('');
  $('#purchaseSupplier').innerHTML = `<option value="">بدون مورد</option>${supplierOptions}`;
}

function findProduct(text) {
  const q = text.trim().toLowerCase(); if (!q) return null;
  return state.products.find(p => p.barcode === text.trim()) || state.products.find(p => p.name.toLowerCase() === q) || null;
}
function matchingProducts(text) { const q=text.trim().toLowerCase(); return state.products.filter(p=>p.barcode.includes(q)||p.name.toLowerCase().includes(q)).slice(0,50); }
function addSaleProduct(product, qty = 1) {
  if (!product) return toast('المنتج غير موجود', 'error');
  const old = state.saleCart.get(product.id); const next = (old?.quantity || 0) + qty;
  if (next > num(product.quantity)) return toast(`المتوفر من ${product.name}: ${fmtQty(product.quantity)}`, 'error');
  state.saleCart.set(product.id, {product, quantity:next, unit_price:num(product.sale_price)}); renderSaleCart(); $('#saleSearch').value=''; $('#saleSearch').focus();
}
function processSaleSearch() {
  const text=$('#saleSearch').value.trim(); if(!text)return;
  const exact=findProduct(text); if(exact){addSaleProduct(exact);return}
  const matches=matchingProducts(text); if(matches.length===1)addSaleProduct(matches[0]); else openProductPicker(matches);
}
function openProductPicker(items = state.products) {
  const root=modal({title:'اختيار منتج',wide:true,body:`<div class="search-box" style="width:100%;margin-bottom:12px"><span>⌕</span><input id="pickerSearch" placeholder="اكتب اسم المنتج أو الباركود"></div><div class="table-scroll" style="max-height:430px"><table class="data-table"><thead><tr><th>الباركود</th><th>المنتج</th><th>المتوفر</th><th>السعر</th><th></th></tr></thead><tbody id="pickerBody"></tbody></table></div>`});
  const render=(list)=>{$('#pickerBody').innerHTML=list.map(p=>`<tr><td>${esc(p.barcode)}</td><td>${esc(p.name)}</td><td>${fmtQty(p.quantity)}</td><td>${money(p.sale_price)}</td><td><button class="btn secondary pick-product" data-id="${p.id}">إضافة</button></td></tr>`).join('')||'<tr><td colspan="5">لا توجد نتائج</td></tr>';$$('.pick-product').forEach(b=>b.onclick=()=>{addSaleProduct(state.products.find(p=>p.id==b.dataset.id));closeModal()})};
  render(items); $('#pickerSearch').oninput=e=>render(matchingProducts(e.target.value)); setTimeout(()=>$('#pickerSearch').focus(),30);
}
function saleTotals(){const subtotal=[...state.saleCart.values()].reduce((s,x)=>s+x.quantity*x.unit_price,0);const discount=Math.max(0,num($('#saleDiscount').value));return{subtotal,total:Math.max(0,subtotal-discount),discount}}
function renderSaleCart(){
  const body=$('#saleCartBody'); const items=[...state.saleCart.values()];
  body.innerHTML=items.map(x=>`<tr><td><strong>${esc(x.product.name)}</strong><br><small>${esc(x.product.barcode)}</small></td><td><div class="qty-control"><button data-qty-minus="${x.product.id}">−</button><input value="${x.quantity}" data-qty-input="${x.product.id}"><button data-qty-plus="${x.product.id}">+</button></div></td><td><input class="price-input" data-price-input="${x.product.id}" type="number" min="0" value="${x.unit_price}" style="width:100px;height:34px;border:1px solid #e2e8ee;border-radius:8px;padding:5px"></td><td><strong>${money(x.quantity*x.unit_price)}</strong></td><td><button class="icon-btn danger" data-cart-remove="${x.product.id}">×</button></td></tr>`).join('');
  $('#emptyCart').classList.toggle('hidden',items.length>0);
  $$('[data-qty-minus]').forEach(b=>b.onclick=()=>changeSaleQty(+b.dataset.qtyMinus,-1));$$('[data-qty-plus]').forEach(b=>b.onclick=()=>changeSaleQty(+b.dataset.qtyPlus,1));$$('[data-cart-remove]').forEach(b=>b.onclick=()=>{state.saleCart.delete(+b.dataset.cartRemove);renderSaleCart()});
  $$('[data-qty-input]').forEach(i=>i.onchange=()=>setSaleQty(+i.dataset.qtyInput,num(i.value)));$$('[data-price-input]').forEach(i=>i.onchange=()=>{const x=state.saleCart.get(+i.dataset.priceInput);x.unit_price=Math.max(0,num(i.value));renderSaleCart()}); updateSaleSummary();
}
function changeSaleQty(id,d){const x=state.saleCart.get(id);setSaleQty(id,x.quantity+d)}
function setSaleQty(id,q){const x=state.saleCart.get(id);if(q<=0){state.saleCart.delete(id)}else if(q>num(x.product.quantity)){toast(`المتوفر فقط ${fmtQty(x.product.quantity)}`,'error')}else{x.quantity=q}renderSaleCart()}
function updateSaleSummary(){const t=saleTotals();$('#cartCount').textContent=[...state.saleCart.values()].reduce((s,x)=>s+x.quantity,0);$('#cartSubtotal').textContent=money(t.subtotal);$('#cartTotal').textContent=money(t.total);if(state.paymentMode==='cash')$('#salePaid').value=t.total}
function setPaymentMode(mode){state.paymentMode=mode;$$('.payment-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.payment===mode));$('#customerField').classList.toggle('hidden',mode==='cash');$('#paidField').classList.toggle('hidden',mode!=='partial');const t=saleTotals();$('#salePaid').value=mode==='cash'?t.total:mode==='debt'?0:Math.min(num($('#salePaid').value),t.total)}
async function completeSale(){
  if(!state.saleCart.size)return toast('الفاتورة فارغة','error'); const t=saleTotals(); let customerId=null,paid=0;
  if(state.paymentMode==='cash')paid=t.total; else {customerId=+$('#saleCustomer').value||null;if(!customerId)return toast('اختر العميل لتسجيل الدين','error');paid=state.paymentMode==='debt'?0:num($('#salePaid').value)}
  const payload={items:[...state.saleCart.values()].map(x=>({product_id:x.product.id,quantity:x.quantity,unit_price:x.unit_price})),customer_id:customerId,discount:t.discount,paid_amount:paid,note:$('#saleNote').value.trim()};
  loading(true);try{const r=await api('/api/sales/create',{method:'POST',body:payload});toast(`تم حفظ الفاتورة ${r.sale.invoice_no}`);const print=$('#printAfterSale').checked;state.saleCart.clear();$('#saleDiscount').value=0;$('#saleNote').value='';setPaymentMode('cash');await reloadCore();renderSaleCart();if(print)window.open(`/invoice/${r.sale.sale_id}`,'_blank','width=430,height=780')}catch(e){toast(e.message,'error',5500)}finally{loading(false)}
}

function renderPurchaseCart(){const items=[...state.purchaseCart.values()];$('#purchaseCartBody').innerHTML=items.map(x=>`<tr><td>${esc(x.product.name)}</td><td>${fmtQty(x.quantity)}</td><td>${money(x.unit_cost)}</td><td>${money(x.quantity*x.unit_cost)}</td><td><button class="icon-btn danger" data-purchase-remove="${x.product.id}">×</button></td></tr>`).join('')||'<tr><td colspan="5">أضف مواد الفاتورة</td></tr>';$$('[data-purchase-remove]').forEach(b=>b.onclick=()=>{state.purchaseCart.delete(+b.dataset.purchaseRemove);renderPurchaseCart()});$('#purchaseTotal').textContent=money([...state.purchaseCart.values()].reduce((s,x)=>s+x.quantity*x.unit_cost,0))}
function addPurchaseItem(){const p=state.products.find(x=>x.id==$('#purchaseProduct').value);if(!p)return toast('اختر المنتج','error');const q=num($('#purchaseQty').value),c=num($('#purchaseCost').value);if(q<=0)return toast('الكمية غير صحيحة','error');state.purchaseCart.set(p.id,{product:p,quantity:q,unit_cost:c});renderPurchaseCart()}
async function completePurchase(){if(!state.purchaseCart.size)return toast('فاتورة الشراء فارغة','error');const total=[...state.purchaseCart.values()].reduce((s,x)=>s+x.quantity*x.unit_cost,0);const supplier=+$('#purchaseSupplier').value||null,paid=num($('#purchasePaid').value);if(paid<total&&!supplier)return toast('اختر المورد عند وجود مبلغ متبقٍ','error');loading(true);try{const r=await api('/api/purchases/create',{method:'POST',body:{items:[...state.purchaseCart.values()].map(x=>({product_id:x.product.id,quantity:x.quantity,unit_cost:x.unit_cost})),supplier_id:supplier,paid_amount:paid,note:$('#purchaseNote').value}});state.purchaseCart.clear();renderPurchaseCart();$('#purchasePaid').value=0;$('#purchaseNote').value='';await reloadCore();toast(`تم حفظ فاتورة الشراء ${r.purchase.invoice_no}`)}catch(e){toast(e.message,'error')}finally{loading(false)}}

function renderCustomers(filter=''){const q=filter.toLowerCase();const items=state.customers.filter(c=>!q||c.name.toLowerCase().includes(q)||(c.phone||'').includes(q));$('#customersCount').textContent=items.length;$('#customersDebtTotal').textContent=money(state.customers.reduce((s,c)=>s+num(c.balance),0));$('#customersBody').innerHTML=items.map(c=>`<tr><td><strong>${esc(c.name)}</strong></td><td>${esc(c.phone||'—')}</td><td>${esc(c.address||'—')}</td><td><strong class="${num(c.balance)>0?'debt-text':''}">${money(c.balance)}</strong></td><td class="actions"><button class="btn secondary customer-statement" data-id="${c.id}">كشف حساب</button><button class="icon-btn customer-edit" data-id="${c.id}">✎</button></td></tr>`).join('')||'<tr><td colspan="5">لا يوجد عملاء</td></tr>';$$('.customer-statement').forEach(b=>b.onclick=()=>openStatement('customer',+b.dataset.id));$$('.customer-edit').forEach(b=>b.onclick=()=>openPartyModal('customer',state.customers.find(c=>c.id==b.dataset.id)))}
function renderSuppliers(filter=''){const q=filter.toLowerCase();const items=state.suppliers.filter(c=>!q||c.name.toLowerCase().includes(q)||(c.phone||'').includes(q));$('#suppliersBody').innerHTML=items.map(c=>`<tr><td><strong>${esc(c.name)}</strong></td><td>${esc(c.phone||'—')}</td><td>${money(c.balance)}</td><td class="actions"><button class="btn secondary supplier-statement" data-id="${c.id}">كشف حساب</button><button class="icon-btn supplier-edit" data-id="${c.id}">✎</button></td></tr>`).join('')||'<tr><td colspan="4">لا يوجد موردون</td></tr>';$$('.supplier-statement').forEach(b=>b.onclick=()=>openStatement('supplier',+b.dataset.id));$$('.supplier-edit').forEach(b=>b.onclick=()=>openPartyModal('supplier',state.suppliers.find(c=>c.id==b.dataset.id)))}
function openPartyModal(kind,party=null){const isCustomer=kind==='customer';modal({title:party?`تعديل ${isCustomer?'العميل':'المورد'}`:`إضافة ${isCustomer?'عميل':'مورد'}`,body:`<label class="field"><span>الاسم *</span><input id="partyName" value="${esc(party?.name||'')}"></label><label class="field"><span>رقم الهاتف</span><input id="partyPhone" value="${esc(party?.phone||'')}"></label><label class="field"><span>العنوان</span><input id="partyAddress" value="${esc(party?.address||'')}"></label><label class="field"><span>ملاحظات</span><textarea id="partyNotes">${esc(party?.notes||'')}</textarea></label>`,actions:`<button class="btn primary" id="saveParty">حفظ</button><button class="btn ghost modal-close-action">إلغاء</button>`});$('.modal-close-action').onclick=closeModal;$('#saveParty').onclick=async()=>{loading(true);try{await api(`/api/${isCustomer?'customers':'suppliers'}/save`,{method:'POST',body:{id:party?.id,name:$('#partyName').value,phone:$('#partyPhone').value,address:$('#partyAddress').value,notes:$('#partyNotes').value}});closeModal();await reloadCore();toast('تم الحفظ')}catch(e){toast(e.message,'error')}finally{loading(false)}};setTimeout(()=>$('#partyName').focus(),30)}
async function openStatement(kind,id){loading(true);try{const r=await api(`/api/${kind==='customer'?'customers':'suppliers'}/${id}/statement`);const d=r.data;const entries=kind==='customer'?d.sales:d.purchases;const total=entries.filter(x=>x.status==='completed').reduce((s,x)=>s+num(x.debt_amount),0);const paid=d.payments.reduce((s,x)=>s+num(x.amount),0);const balance=total-paid;modal({title:`كشف حساب — ${d.party.name}`,wide:true,body:`<div class="statement-summary"><div><span>إجمالي الدين</span><strong>${money(total)}</strong></div><div><span>الدفعات</span><strong>${money(paid)}</strong></div><div><span>المتبقي</span><strong>${money(balance)}</strong></div></div><div class="table-scroll" style="max-height:320px"><table class="data-table"><thead><tr><th>الرقم</th><th>التاريخ</th><th>القيمة</th><th>الدين</th><th>الحالة</th></tr></thead><tbody>${entries.map(x=>`<tr><td>${esc(x.invoice_no)}</td><td>${esc(x.created_at)}</td><td>${money(x.total)}</td><td>${money(x.debt_amount)}</td><td>${x.status==='completed'?'مكتملة':'ملغاة'}</td></tr>`).join('')||'<tr><td colspan="5">لا توجد فواتير</td></tr>'}</tbody></table></div>`,actions:`<button class="btn primary" id="statementPayment">تسجيل دفعة</button><button class="btn ghost modal-close-action">إغلاق</button>`});$('.modal-close-action').onclick=closeModal;$('#statementPayment').onclick=()=>openPaymentModal(kind,id,d.party.name)}catch(e){toast(e.message,'error')}finally{loading(false)}}
function openPaymentModal(kind,id,name){modal({title:`تسجيل دفعة — ${name}`,body:`<label class="field"><span>قيمة الدفعة</span><input id="paymentAmount" type="number" min="1"></label><label class="field"><span>ملاحظة</span><input id="paymentNote" placeholder="اختياري"></label>`,actions:`<button class="btn primary" id="savePayment">حفظ الدفعة</button><button class="btn ghost modal-close-action">إلغاء</button>`});$('.modal-close-action').onclick=closeModal;$('#savePayment').onclick=async()=>{loading(true);try{await api(`/api/${kind==='customer'?'customers':'suppliers'}/${id}/payments`,{method:'POST',body:{amount:num($('#paymentAmount').value),note:$('#paymentNote').value}});closeModal();await reloadCore();toast('تم تسجيل الدفعة')}catch(e){toast(e.message,'error')}finally{loading(false)}}}

async function loadInventoryProduct(barcode){const p=state.products.find(x=>x.barcode===barcode.trim());state.inventoryProduct=p||null;if(!p){$('#countProductCard').classList.add('hidden');return toast('الباركود غير موجود','error')}$('#countProductCard').classList.remove('hidden');$('#countProductCard').innerHTML=`<div><strong>${esc(p.name)}</strong><br><span>${esc(p.barcode)} · ${esc(p.unit)}</span></div><div><span>المسجل بالنظام</span><strong>${fmtQty(p.quantity)}</strong></div>`;$('#countedQty').value=p.quantity;$('#countedQty').focus();$('#countedQty').select()}
async function saveInventory(){if(!state.inventoryProduct)return toast('اقرأ باركود المنتج أولاً','error');loading(true);try{const r=await api('/api/inventory/adjust',{method:'POST',body:{product_id:state.inventoryProduct.id,counted_quantity:num($('#countedQty').value),note:$('#inventoryNote').value}});toast(`تم اعتماد الجرد. الفرق ${fmtQty(r.difference)}`);state.inventoryProduct=null;$('#inventoryBarcode').value='';$('#inventoryNote').value='';$('#countProductCard').classList.add('hidden');await reloadCore();loadMovements();$('#inventoryBarcode').focus()}catch(e){toast(e.message,'error')}finally{loading(false)}}
async function loadMovements(){try{const r=await api('/api/stock/movements?limit=250');const names={sale:'بيع',purchase:'شراء',inventory:'جرد',opening:'رصيد افتتاحي',manual_edit:'تعديل يدوي',sale_void:'إلغاء بيع',purchase_void:'إلغاء شراء'};$('#movementsBody').innerHTML=r.items.map(x=>`<tr><td>${esc(x.product_name)}</td><td>${names[x.movement_type]||esc(x.movement_type)}</td><td><span class="badge ${num(x.quantity_delta)>=0?'success':'warning'}">${num(x.quantity_delta)>0?'+':''}${fmtQty(x.quantity_delta)}</span></td><td>${esc(x.created_at)}</td></tr>`).join('')||'<tr><td colspan="4">لا توجد حركات</td></tr>'}catch(e){toast(e.message,'error')}}

function refreshReportDates(period){if(period==='today'){$('#reportFrom').value=today();$('#reportTo').value=today()}else if(period==='month'){$('#reportFrom').value=monthStart();$('#reportTo').value=today()}}
async function refreshReport(){const d1=$('#reportFrom').value||today(),d2=$('#reportTo').value||d1;try{const r=await api(`/api/reports/data?from=${encodeURIComponent(d1)}&to=${encodeURIComponent(d2)}`);const d=r.data;$('#reportSales').textContent=money(d.summary.sales_total);$('#reportPaid').textContent=money(d.summary.sales_paid);$('#reportDebt').textContent=money(d.summary.sales_debt);$('#reportProfit').textContent=money(d.net_profit)}catch(e){toast(e.message,'error')}}
async function reportAction(action){const payload={from:$('#reportFrom').value||today(),to:$('#reportTo').value||today(),type:state.reportType,phone:state.settings.owner_phone||''};loading(true);try{const r=await api(`/api/reports/${action}`,{method:'POST',body:payload});toast(action==='whatsapp'?'تم فتح واتساب وتجهيز التقرير':'تم إنشاء الملف وفتح مجلده')}catch(e){toast(e.message,'error')}finally{loading(false)}}
async function refreshRecords(){try{if(state.recordsMode==='sales'){const r=await api('/api/sales?limit=300');$('#recordsHead').innerHTML='<tr><th>رقم الفاتورة</th><th>التاريخ</th><th>العميل</th><th>الإجمالي</th><th>الدين</th><th>الحالة</th><th></th></tr>';$('#recordsBody').innerHTML=r.items.map(x=>`<tr><td>${esc(x.invoice_no)}</td><td>${esc(x.created_at)}</td><td>${esc(x.customer_name)}</td><td>${money(x.total)}</td><td>${money(x.debt_amount)}</td><td><span class="badge ${x.status==='completed'?'success':'danger'}">${x.status==='completed'?'مكتملة':'ملغاة'}</span></td><td><button class="btn secondary record-detail" data-id="${x.id}" data-kind="sale">تفاصيل</button></td></tr>`).join('')||'<tr><td colspan="7">لا توجد فواتير</td></tr>'}else{const r=await api('/api/purchases?limit=300');$('#recordsHead').innerHTML='<tr><th>رقم الفاتورة</th><th>التاريخ</th><th>المورد</th><th>الإجمالي</th><th>المتبقي</th><th>الحالة</th><th></th></tr>';$('#recordsBody').innerHTML=r.items.map(x=>`<tr><td>${esc(x.invoice_no)}</td><td>${esc(x.created_at)}</td><td>${esc(x.supplier_name)}</td><td>${money(x.total)}</td><td>${money(x.debt_amount)}</td><td><span class="badge ${x.status==='completed'?'success':'danger'}">${x.status==='completed'?'مكتملة':'ملغاة'}</span></td><td><button class="btn secondary record-detail" data-id="${x.id}" data-kind="purchase">تفاصيل</button></td></tr>`).join('')||'<tr><td colspan="7">لا توجد فواتير</td></tr>'}$$('.record-detail').forEach(b=>b.onclick=()=>openRecordDetail(b.dataset.kind,+b.dataset.id))}catch(e){toast(e.message,'error')}}
async function openRecordDetail(kind,id){loading(true);try{const r=await api(`/api/${kind==='sale'?'sales':'purchases'}/${id}/items`);const items=r.items;modal({title:`تفاصيل ${kind==='sale'?'فاتورة البيع':'فاتورة الشراء'}`,wide:true,body:`<div class="table-scroll" style="max-height:420px"><table class="data-table"><thead><tr><th>الباركود</th><th>المنتج</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>${items.map(x=>`<tr><td>${esc(x.barcode)}</td><td>${esc(x.product_name)}</td><td>${fmtQty(x.quantity)}</td><td>${money(kind==='sale'?x.unit_price:x.unit_cost)}</td><td>${money(x.line_total)}</td></tr>`).join('')}</tbody></table></div>`,actions:`${kind==='sale'?`<button class="btn primary" onclick="window.open('/invoice/${id}','_blank')">طباعة</button>`:''}<button class="btn ghost" id="voidRecord">إلغاء الفاتورة وعكس أثرها</button><button class="btn ghost modal-close-action">إغلاق</button>`});$('.modal-close-action').onclick=closeModal;$('#voidRecord').onclick=async()=>{if(!confirmAction('هل أنت متأكد؟ سيتم عكس أثر الفاتورة على المخزون والذمم.'))return;const reason=prompt('سبب الإلغاء:','خطأ في الفاتورة')||'إلغاء';loading(true);try{await api(`/api/${kind==='sale'?'sales':'purchases'}/${id}/void`,{method:'POST',body:{reason}});closeModal();await reloadCore();await refreshRecords();toast('تم إلغاء الفاتورة وعكس أثرها')}catch(e){toast(e.message,'error')}finally{loading(false)}}}catch(e){toast(e.message,'error')}finally{loading(false)}}

function setupScannerInfo(scanner){$('#scannerEndpoint').textContent=`http://${scanner.ip}:${scanner.port}`;$('#scannerToken').textContent=scanner.token.replace(/(.{3})/,'$1 ')}
async function scannerPoll(){try{const r=await api(`/api/scanner/poll?after=${state.lastScannerEvent}`);for(const e of r.events){state.lastScannerEvent=Math.max(state.lastScannerEvent,e.id);$('#lastMobileScan').textContent=e.product?`${e.product.name} — ${e.barcode}`:`غير معروف — ${e.barcode}`;if(e.mode==='inventory'){goPage('inventory');selectInventoryTab('count');$('#inventoryBarcode').value=e.barcode;loadInventoryProduct(e.barcode)}else if(e.mode==='stock'){goPage('inventory');selectInventoryTab('products');$('#productSearch').value=e.barcode;renderProducts(e.barcode);const p=state.products.find(x=>x.barcode===e.barcode);toast(p?`${p.name} — المتوفر ${fmtQty(p.quantity)}`:`باركود غير مضاف: ${e.barcode}`,p?'success':'error')}else{goPage('cashier');const p=state.products.find(x=>x.barcode===e.barcode);if(p)addSaleProduct(p);else toast(`باركود غير مضاف: ${e.barcode}`,'error')}}}catch{}finally{setTimeout(scannerPoll,700)}}

async function reloadCore(){const r=await api('/api/bootstrap');state.settings=r.settings;state.dashboard=r.dashboard;state.products=r.products;state.customers=r.customers;state.suppliers=r.suppliers;state.rateLog=r.rate_log||[];renderAll();setupScannerInfo(r.scanner)}
async function createBackup(){loading(true);try{const r=await api('/api/backup/create',{method:'POST',body:{}});await reloadCore();toast('تم إنشاء النسخة وفتح مجلدها')}catch(e){toast(e.message,'error')}finally{loading(false)}}
async function restoreBackup(file){if(!file)return;if(!confirmAction('سيتم استبدال البيانات الحالية بمحتوى النسخة. سينشئ النظام نسخة أمان أولاً. متابعة؟'))return;loading(true);try{const buf=await file.arrayBuffer();const r=await api('/api/backup/restore',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-Filename':encodeURIComponent(file.name)},body:buf});await reloadCore();toast('تمت الاستعادة بنجاح. أعد فتح البرنامج للتأكد من كل البيانات.', 'success',6000)}catch(e){toast(e.message,'error',6000)}finally{loading(false);$('#restoreFile').value=''}}

// ---------- سعر الدولار ----------
function renderUsdRate(){
  const rate=usdRate(); const s=state.settings;
  const badge=$('#usdRateBadge'); if(badge){badge.classList.toggle('unset',!rate);$('#usdRateBadgeText').textContent=rate?`الدولار: ${Number(rate).toLocaleString('ar',{maximumFractionDigits:4})}`:'الدولار: غير محدد'}
  $('#usdRateCurrent').textContent=rate?`1$ = ${Number(rate).toLocaleString('en-US',{maximumFractionDigits:4})} ${s.currency||'ل.س'}`:'لم يُحدد بعد';
  $('#usdRateStatus').textContent=rate?'مفعّل':'غير محدد';$('#usdRateStatus').className=`badge ${rate?'success':'warning'}`;
  if(document.activeElement!==$('#usdRateInput'))$('#usdRateInput').value=rate||'';
  $('#priceRounding').value=ROUNDING_STEPS[s.price_rounding]!==undefined?s.price_rounding:'none';
  const log=state.rateLog||[];
  $('#rateLogList').innerHTML=log.length?log.slice(0,8).map(x=>`<div class="simple-item"><div><strong>${num(x.old_rate)?`${Number(x.old_rate).toLocaleString('en-US',{maximumFractionDigits:4})} ← `:''}${Number(x.new_rate).toLocaleString('en-US',{maximumFractionDigits:4})}</strong><br><span>${esc(x.created_at)} · ${esc(ROUNDING_LABELS[x.rounding]||x.rounding)}</span></div><span class="qty-badge">${x.products_updated} منتج</span></div>`).join(''):'<div class="help-text">لا توجد تغييرات بعد.</div>';
}
async function previewUsdRate(){
  const rate=num($('#usdRateInput').value),rounding=$('#priceRounding').value;
  if(rate<=0){toast('اكتب سعر الدولار أولاً (رقم أكبر من صفر)','error');$('#usdRateInput').focus();return}
  loading(true);
  try{
    const r=await api('/api/usd-rate/preview',{method:'POST',body:{rate,rounding}});const d=r.preview;
    const items=[...d.items].sort((a,b)=>(Math.abs(b.new_price-b.old_price)>1e-9)-(Math.abs(a.new_price-a.old_price)>1e-9));
    const shown=items.slice(0,600);
    const rows=shown.map(x=>{const diff=x.new_price-x.old_price;const cls=Math.abs(diff)<1e-9?'price-same':diff>0?'price-up':'price-down';return `<tr><td>${esc(x.barcode)}</td><td>${esc(x.name)}</td><td style="direction:ltr;text-align:right">${fmtUsd(x.usd_price)}</td><td>${money(x.old_price)}</td><td class="${cls}">${money(x.new_price)}</td></tr>`}).join('')||'<tr><td colspan="5">لا توجد منتجات مسعّرة بالدولار</td></tr>';
    const note=d.first_time?`<div class="info-note">هاي أول مرة بينحط فيها سعر الدولار. الأسعار الحالية بتنحسب على أساس <b>${esc(String(d.new_rate))}</b>، فما رح يتغير شي هلق${rounding!=='none'?' إلا التقريب':''}. من المرة الجاية، كل ما تغيّر سعر الدولار بتتعدل الأسعار لحالها.</div>`:'';
    modal({title:'معاينة الأسعار الجديدة',wide:true,body:`${note}<div class="preview-summary"><div><span>السعر القديم</span><strong>${d.old_rate?Number(d.old_rate).toLocaleString('en-US',{maximumFractionDigits:4}):'—'}</strong></div><div><span>السعر الجديد</span><strong>${Number(d.new_rate).toLocaleString('en-US',{maximumFractionDigits:4})}</strong></div><div><span>منتجات رح يتغير سعرها</span><strong>${d.changed_count}</strong></div><div><span>ثابتة بالليرة (ما بتتغير)</span><strong>${d.fixed_count}</strong></div></div><p class="help-text">التقريب: ${esc(ROUNDING_LABELS[rounding]||rounding)}${items.length>shown.length?` · معروض أول ${shown.length} منتج من ${items.length}`:''}</p><div class="table-scroll" style="max-height:380px"><table class="data-table"><thead><tr><th>الباركود</th><th>المنتج</th><th>بالدولار</th><th>السعر الحالي</th><th>السعر الجديد</th></tr></thead><tbody>${rows}</tbody></table></div>`,actions:`<button class="btn primary" id="applyRateBtn">اعتماد وتحديث الأسعار</button><button class="btn ghost modal-close-action">إلغاء</button>`});
    $('.modal-close-action').onclick=closeModal;
    $('#applyRateBtn').onclick=()=>applyUsdRate(rate,rounding);
  }catch(e){toast(e.message,'error',5500)}finally{loading(false)}
}
async function applyUsdRate(rate,rounding){
  loading(true);
  try{
    const r=await api('/api/usd-rate/apply',{method:'POST',body:{rate,rounding}});
    closeModal();await reloadCore();
    // تحديث أسعار الفاتورة المفتوحة حالياً على الأسعار الجديدة
    for(const [id,item] of state.saleCart){const p=state.products.find(x=>x.id===id);if(p){item.product=p;item.unit_price=num(p.sale_price)}}
    renderSaleCart();
    toast(`تم اعتماد سعر الدولار ${Number(rate).toLocaleString('en-US',{maximumFractionDigits:4})} وتحديث ${r.result.changed_count} منتج`,'success',5000);
  }catch(e){toast(e.message,'error',5500)}finally{loading(false)}
}

function bindEvents(){
  $$('.nav-item').forEach(b=>b.onclick=()=>goPage(b.dataset.page));$$('[data-go]').forEach(b=>b.onclick=()=>{goPage(b.dataset.go);if(b.dataset.sub)selectInventoryTab(b.dataset.sub)});
  $('#quickSaleBtn').onclick=()=>goPage('cashier');$('#quickBackupBtn').onclick=createBackup;$('#quickBackupBtn').onclick=createBackup;$('#createBackupBtn').onclick=createBackup;
  $('#dailyWhatsappBtn').onclick=()=>{goPage('reports');refreshReportDates('today');state.reportType='full';reportAction('whatsapp')};
  $('#quickAddProduct').onclick=()=>openProductModal();$('#addProductBtn').onclick=()=>openProductModal();$('#quickPurchase').onclick=()=>{goPage('inventory');selectInventoryTab('purchases')};$('#quickReport').onclick=()=>{goPage('reports');refreshReportDates('today');refreshReport()};
  $('#saleSearch').addEventListener('keydown',e=>{if(e.key==='Enter')processSaleSearch()});$('#clearSaleSearch').onclick=()=>{$('#saleSearch').value='';$('#saleSearch').focus()};$('#saleProductPicker').onclick=()=>openProductPicker();$('#clearCartBtn').onclick=()=>{if(state.saleCart.size&&confirmAction('مسح جميع أصناف الفاتورة؟')){state.saleCart.clear();renderSaleCart()}};
  $('#saleDiscount').oninput=updateSaleSummary;$$('.payment-tabs button').forEach(b=>b.onclick=()=>setPaymentMode(b.dataset.payment));$('#completeSaleBtn').onclick=completeSale;
  $$('#inventoryTabs button').forEach(b=>b.onclick=()=>selectInventoryTab(b.dataset.tab));$('#productSearch').oninput=e=>renderProducts(e.target.value);$('#addPurchaseItem').onclick=addPurchaseItem;$('#completePurchase').onclick=completePurchase;$('#purchaseProduct').onchange=()=>{const p=state.products.find(x=>x.id==$('#purchaseProduct').value);if(p)$('#purchaseCost').value=p.purchase_price};
  $('#addSupplierBtn').onclick=()=>openPartyModal('supplier');$('#supplierSearch').oninput=e=>renderSuppliers(e.target.value);$('#addCustomerBtn').onclick=()=>openPartyModal('customer');$('#customerSearch').oninput=e=>renderCustomers(e.target.value);
  $('#inventoryBarcode').addEventListener('keydown',e=>{if(e.key==='Enter')loadInventoryProduct(e.target.value)});$('#saveInventoryCount').onclick=saveInventory;$('#exportShortages').onclick=()=>{goPage('reports');state.reportType='shortages';$$('.report-type').forEach(b=>b.classList.toggle('active',b.dataset.type==='shortages'));reportAction('export')};
  $$('.date-presets button').forEach(b=>b.onclick=()=>{$$('.date-presets button').forEach(x=>x.classList.toggle('active',x===b));refreshReportDates(b.dataset.period);refreshReport()});$$('.report-type').forEach(b=>b.onclick=()=>{$$('.report-type').forEach(x=>x.classList.toggle('active',x===b));state.reportType=b.dataset.type});$('#refreshReportPreview').onclick=refreshReport;$('#exportReportBtn').onclick=()=>reportAction('export');$('#sendWhatsappBtn').onclick=()=>reportAction('whatsapp');$('#exportCsvBtn').onclick=()=>reportAction('csv');
  $('#addExpenseBtn').onclick=()=>{modal({title:'إضافة مصروف',body:`<label class="field"><span>التصنيف</span><input id="expenseCategory" value="عام"></label><label class="field"><span>القيمة</span><input id="expenseAmount" type="number" min="1"></label><label class="field"><span>ملاحظة</span><input id="expenseNote"></label>`,actions:`<button class="btn primary" id="saveExpense">حفظ</button><button class="btn ghost modal-close-action">إلغاء</button>`});$('.modal-close-action').onclick=closeModal;$('#saveExpense').onclick=async()=>{loading(true);try{await api('/api/expenses/add',{method:'POST',body:{category:$('#expenseCategory').value,amount:num($('#expenseAmount').value),note:$('#expenseNote').value}});closeModal();refreshReport();toast('تم تسجيل المصروف')}catch(e){toast(e.message,'error')}finally{loading(false)}}};
  $$('#recordsTabs button').forEach(b=>b.onclick=()=>{$$('#recordsTabs button').forEach(x=>x.classList.toggle('active',x===b));state.recordsMode=b.dataset.record;refreshRecords()});
  $('#saveSettingsBtn').onclick=async()=>{loading(true);try{const r=await api('/api/settings/save',{method:'POST',body:{store_name:$('#settingStoreName').value,owner_phone:$('#settingOwnerPhone').value,currency:$('#settingCurrency').value,operator_name:$('#settingOperator').value}});state.settings=r.settings;renderAll();toast('تم حفظ الإعدادات')}catch(e){toast(e.message,'error')}finally{loading(false)}};
  $('#resetScannerToken').onclick=async()=>{if(!confirmAction('سيحتاج تطبيق الهاتف إلى إدخال الرمز الجديد. متابعة؟'))return;try{const r=await api('/api/scanner/token/reset',{method:'POST',body:{}});$('#scannerToken').textContent=r.token.replace(/(.{3})/,'$1 ');toast('تم تغيير رمز الربط')}catch(e){toast(e.message,'error')}};
  $('#openBackupsBtn').onclick=()=>api('/api/system/open-folder',{method:'POST',body:{target:'backups'}});$('#openReportsBtn').onclick=()=>api('/api/system/open-folder',{method:'POST',body:{target:'reports'}});$('#restoreFile').onchange=e=>restoreBackup(e.target.files[0]);
  $('#scannerStatusBtn').onclick=()=>goPage('settings');
  $('#usdRateBadge').onclick=()=>{goPage('settings');setTimeout(()=>{$('#usdRateCard').scrollIntoView({behavior:'smooth',block:'start'});$('#usdRateInput').focus();$('#usdRateInput').select()},90)};
  $('#previewRateBtn').onclick=previewUsdRate;
  $('#usdRateInput').addEventListener('keydown',e=>{if(e.key==='Enter')previewUsdRate()});
  $('#licenseBadgeBtn').onclick=()=>goPage('settings');
  $('#activateLicenseBtn').onclick=()=>activateLicense('licenseCode');
  $('#overlayActivateBtn').onclick=()=>activateLicense('overlayLicenseCode');
  $('#licenseWhatsappBtn').onclick=openActivationWhatsapp;$('#overlayWhatsappBtn').onclick=openActivationWhatsapp;
  $('#copyInstallIdBtn').onclick=copyInstallId;
  $('#overlayBackupBtn').onclick=()=>{goPage('settings');$('#licenseOverlay').classList.add('hidden')};
}

document.addEventListener('DOMContentLoaded',()=>{bindEvents();refreshLicense();bootstrap().then(scannerPoll);setInterval(refreshLicense,60000)});
