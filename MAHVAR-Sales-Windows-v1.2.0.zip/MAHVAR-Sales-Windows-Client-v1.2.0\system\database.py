from __future__ import annotations

import math
import os
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, date
from pathlib import Path
from typing import Any, Iterable


APP_DIR_NAME = "RasidiSales"


def app_data_dir() -> Path:
    root = os.getenv("LOCALAPPDATA")
    if root:
        base = Path(root) / APP_DIR_NAME
    else:
        base = Path.home() / ".rasidi_sales"
    base.mkdir(parents=True, exist_ok=True)
    return base


def documents_dir() -> Path:
    path = Path.home() / "Documents"
    path.mkdir(parents=True, exist_ok=True)
    return path


@dataclass
class SaleResult:
    sale_id: int
    invoice_no: str
    total: float
    paid: float
    debt: float


class Database:
    def __init__(self, db_path: Path | None = None) -> None:
        self.path = db_path or app_data_dir() / "rasidi_sales.db"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.init_schema()

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = FULL")
        conn.execute("PRAGMA busy_timeout = 30000")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def init_schema(self) -> None:
        with self.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    barcode TEXT NOT NULL UNIQUE,
                    name TEXT NOT NULL,
                    category TEXT DEFAULT '',
                    purchase_price REAL NOT NULL DEFAULT 0,
                    sale_price REAL NOT NULL DEFAULT 0,
                    quantity REAL NOT NULL DEFAULT 0,
                    minimum_stock REAL NOT NULL DEFAULT 0,
                    unit TEXT NOT NULL DEFAULT 'قطعة',
                    expiry_date TEXT DEFAULT '',
                    active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
                CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);

                CREATE TABLE IF NOT EXISTS customers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    phone TEXT DEFAULT '',
                    address TEXT DEFAULT '',
                    notes TEXT DEFAULT '',
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS suppliers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    phone TEXT DEFAULT '',
                    address TEXT DEFAULT '',
                    notes TEXT DEFAULT '',
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS sales (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    invoice_no TEXT NOT NULL UNIQUE,
                    customer_id INTEGER,
                    subtotal REAL NOT NULL,
                    discount REAL NOT NULL DEFAULT 0,
                    total REAL NOT NULL,
                    paid_amount REAL NOT NULL,
                    debt_amount REAL NOT NULL,
                    payment_type TEXT NOT NULL,
                    note TEXT DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'completed',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(customer_id) REFERENCES customers(id)
                );

                CREATE TABLE IF NOT EXISTS sale_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sale_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    barcode TEXT NOT NULL,
                    product_name TEXT NOT NULL,
                    quantity REAL NOT NULL,
                    unit_price REAL NOT NULL,
                    cost_price REAL NOT NULL,
                    line_total REAL NOT NULL,
                    FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE,
                    FOREIGN KEY(product_id) REFERENCES products(id)
                );

                CREATE TABLE IF NOT EXISTS purchases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    invoice_no TEXT NOT NULL UNIQUE,
                    supplier_id INTEGER,
                    subtotal REAL NOT NULL,
                    total REAL NOT NULL,
                    paid_amount REAL NOT NULL,
                    debt_amount REAL NOT NULL,
                    note TEXT DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'completed',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
                );

                CREATE TABLE IF NOT EXISTS purchase_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    purchase_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    barcode TEXT NOT NULL,
                    product_name TEXT NOT NULL,
                    quantity REAL NOT NULL,
                    unit_cost REAL NOT NULL,
                    line_total REAL NOT NULL,
                    FOREIGN KEY(purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
                    FOREIGN KEY(product_id) REFERENCES products(id)
                );

                CREATE TABLE IF NOT EXISTS customer_payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id INTEGER NOT NULL,
                    amount REAL NOT NULL,
                    note TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(customer_id) REFERENCES customers(id)
                );

                CREATE TABLE IF NOT EXISTS supplier_payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    supplier_id INTEGER NOT NULL,
                    amount REAL NOT NULL,
                    note TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
                );

                CREATE TABLE IF NOT EXISTS stock_movements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    movement_type TEXT NOT NULL,
                    quantity_delta REAL NOT NULL,
                    reference_type TEXT DEFAULT '',
                    reference_id INTEGER,
                    note TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(product_id) REFERENCES products(id)
                );

                CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL,
                    amount REAL NOT NULL,
                    note TEXT DEFAULT '',
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS inventory_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    product_id INTEGER NOT NULL,
                    system_quantity REAL NOT NULL,
                    counted_quantity REAL NOT NULL,
                    difference REAL NOT NULL,
                    note TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(product_id) REFERENCES products(id)
                );

                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    action TEXT NOT NULL,
                    entity_type TEXT NOT NULL,
                    entity_id INTEGER,
                    details TEXT DEFAULT '',
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS exchange_rate_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    old_rate REAL NOT NULL DEFAULT 0,
                    new_rate REAL NOT NULL,
                    rounding TEXT NOT NULL DEFAULT 'none',
                    products_updated INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                );
                """
            )
            # ترقية قواعد البيانات القديمة: أعمدة تسعير الدولار للمنتجات
            columns = {row["name"] for row in conn.execute("PRAGMA table_info(products)")}
            if "usd_price" not in columns:
                conn.execute("ALTER TABLE products ADD COLUMN usd_price REAL")
            if "usd_linked" not in columns:
                conn.execute("ALTER TABLE products ADD COLUMN usd_linked INTEGER NOT NULL DEFAULT 1")
            defaults = {
                "store_name": "رصيدي للمبيعات",
                "owner_phone": "",
                "currency": "ل.س",
                "operator_name": "الكاشير",
                "last_backup_date": "",
                "usd_rate": "",
                "price_rounding": "none",
            }
            for key, value in defaults.items():
                conn.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (key, value))

    @staticmethod
    def now() -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def get_setting(self, key: str, default: str = "") -> str:
        with self.connect() as conn:
            row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
            return str(row["value"]) if row else default

    def set_setting(self, key: str, value: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value)),
            )

    def all_settings(self) -> dict[str, str]:
        with self.connect() as conn:
            return {row["key"]: row["value"] for row in conn.execute("SELECT key,value FROM settings")}

    def audit(self, conn: sqlite3.Connection, action: str, entity_type: str, entity_id: int | None, details: str = "") -> None:
        conn.execute(
            "INSERT INTO audit_log(action, entity_type, entity_id, details, created_at) VALUES(?,?,?,?,?)",
            (action, entity_type, entity_id, details, self.now()),
        )

    # ---------- Dollar rate ----------
    ROUNDING_STEPS = {"none": 0.0, "0.5": 0.5, "1": 1.0, "5": 5.0, "10": 10.0, "50": 50.0, "100": 100.0}

    @classmethod
    def round_price(cls, value: float, rounding: str) -> float:
        step = cls.ROUNDING_STEPS.get(str(rounding), 0.0)
        value = max(float(value or 0), 0.0)
        if step <= 0:
            return round(value, 2)
        rounded = round(math.floor(value / step + 0.5 + 1e-9) * step, 2)
        # منتج رخيص أقل من نصف خطوة التقريب: لا نصفّر سعره، نتركه بدون تقريب
        return rounded if rounded > 0 or value <= 0 else round(value, 2)

    def _rate(self, conn: sqlite3.Connection) -> float:
        row = conn.execute("SELECT value FROM settings WHERE key='usd_rate'").fetchone()
        try:
            return max(float(row["value"]), 0.0) if row and str(row["value"]).strip() else 0.0
        except (TypeError, ValueError):
            return 0.0

    def get_usd_rate(self) -> float:
        with self.connect() as conn:
            return self._rate(conn)

    def _plan_rate_change(self, conn: sqlite3.Connection, new_rate: float, rounding: str) -> list[dict[str, Any]]:
        old_rate = self._rate(conn)
        plan: list[dict[str, Any]] = []
        products = conn.execute(
            "SELECT id, barcode, name, sale_price, usd_price FROM products WHERE active=1 AND usd_linked=1 ORDER BY name COLLATE NOCASE"
        ).fetchall()
        for p in products:
            old_price = float(p["sale_price"] or 0)
            usd = p["usd_price"]
            if usd is None:
                # منتج لم يُحسب سعره بالدولار بعد: نعتبر سعره الحالي محسوباً على السعر السابق
                # (أو على السعر الجديد إن كانت هذه أول مرة يُضبط فيها سعر الدولار)
                base = old_rate if old_rate > 0 else new_rate
                usd = old_price / base if base > 0 else 0.0
            usd = float(usd or 0)
            new_price = self.round_price(usd * new_rate, rounding)
            plan.append({
                "id": int(p["id"]),
                "barcode": p["barcode"],
                "name": p["name"],
                "usd_price": usd,
                "old_price": old_price,
                "new_price": new_price,
            })
        return plan

    def preview_rate_change(self, new_rate: float, rounding: str) -> dict[str, Any]:
        new_rate = float(new_rate or 0)
        if new_rate <= 0:
            raise ValueError("اكتب سعر دولار صحيح أكبر من صفر")
        with self.connect() as conn:
            old_rate = self._rate(conn)
            plan = self._plan_rate_change(conn, new_rate, rounding)
            fixed = conn.execute("SELECT COUNT(*) c FROM products WHERE active=1 AND usd_linked=0").fetchone()["c"]
        changed = [x for x in plan if abs(x["new_price"] - x["old_price"]) > 1e-9]
        return {
            "old_rate": old_rate,
            "new_rate": new_rate,
            "rounding": rounding,
            "first_time": old_rate <= 0,
            "items": plan,
            "changed_count": len(changed),
            "linked_count": len(plan),
            "fixed_count": int(fixed or 0),
        }

    def apply_rate_change(self, new_rate: float, rounding: str) -> dict[str, Any]:
        new_rate = float(new_rate or 0)
        if new_rate <= 0:
            raise ValueError("اكتب سعر دولار صحيح أكبر من صفر")
        if str(rounding) not in self.ROUNDING_STEPS:
            rounding = "none"
        now = self.now()
        with self.connect() as conn:
            old_rate = self._rate(conn)
            plan = self._plan_rate_change(conn, new_rate, rounding)
            changed = 0
            for item in plan:
                if abs(item["new_price"] - item["old_price"]) > 1e-9:
                    changed += 1
                conn.execute(
                    "UPDATE products SET usd_price=?, sale_price=?, updated_at=? WHERE id=?",
                    (item["usd_price"], item["new_price"], now, item["id"]),
                )
            for key, value in (("usd_rate", f"{new_rate:g}"), ("price_rounding", rounding)):
                conn.execute(
                    "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, value),
                )
            cur = conn.execute(
                "INSERT INTO exchange_rate_log(old_rate,new_rate,rounding,products_updated,created_at) VALUES(?,?,?,?,?)",
                (old_rate, new_rate, rounding, changed, now),
            )
            self.audit(conn, "usd_rate", "settings", int(cur.lastrowid), f"{old_rate:g} -> {new_rate:g} ({changed} منتج)")
        return {"old_rate": old_rate, "new_rate": new_rate, "changed_count": changed, "linked_count": len(plan)}

    def list_rate_log(self, limit: int = 15) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return list(conn.execute("SELECT * FROM exchange_rate_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall())

    # ---------- Products ----------
    def list_products(self, search: str = "", active_only: bool = True) -> list[sqlite3.Row]:
        sql = "SELECT * FROM products WHERE 1=1"
        params: list[Any] = []
        if active_only:
            sql += " AND active=1"
        if search.strip():
            sql += " AND (name LIKE ? OR barcode LIKE ? OR category LIKE ?)"
            q = f"%{search.strip()}%"
            params.extend([q, q, q])
        sql += " ORDER BY name COLLATE NOCASE"
        with self.connect() as conn:
            return list(conn.execute(sql, params).fetchall())

    def get_product(self, product_id: int) -> sqlite3.Row | None:
        with self.connect() as conn:
            return conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()

    def get_product_by_barcode(self, barcode: str) -> sqlite3.Row | None:
        with self.connect() as conn:
            return conn.execute("SELECT * FROM products WHERE barcode=? AND active=1", (barcode.strip(),)).fetchone()

    def save_product(self, data: dict[str, Any], product_id: int | None = None) -> int:
        barcode = str(data.get("barcode", "")).strip()
        name = str(data.get("name", "")).strip()
        if not barcode or not name:
            raise ValueError("الباركود واسم المنتج مطلوبان")
        now = self.now()
        values = (
            barcode,
            name,
            str(data.get("category", "")).strip(),
            float(data.get("purchase_price") or 0),
            float(data.get("sale_price") or 0),
            float(data.get("quantity") or 0),
            float(data.get("minimum_stock") or 0),
            str(data.get("unit", "قطعة")).strip() or "قطعة",
            str(data.get("expiry_date", "")).strip(),
            now,
        )
        raw_linked = data.get("usd_linked", True)
        usd_linked = 0 if str(raw_linked).strip().lower() in {"0", "false", "no", ""} or raw_linked is False else 1
        with self.connect() as conn:
            rate = self._rate(conn)
            usd_price: float | None = None
            if usd_linked and rate > 0:
                raw_usd = data.get("usd_price")
                if raw_usd not in (None, "") and float(raw_usd) >= 0:
                    usd_price = float(raw_usd)
                else:
                    usd_price = float(data.get("sale_price") or 0) / rate
            try:
                if product_id:
                    old = conn.execute("SELECT quantity FROM products WHERE id=?", (product_id,)).fetchone()
                    if not old:
                        raise ValueError("المنتج غير موجود")
                    conn.execute(
                        """UPDATE products SET barcode=?,name=?,category=?,purchase_price=?,sale_price=?,quantity=?,minimum_stock=?,unit=?,expiry_date=?,updated_at=? WHERE id=?""",
                        values + (product_id,),
                    )
                    conn.execute("UPDATE products SET usd_price=?, usd_linked=? WHERE id=?", (usd_price, usd_linked, product_id))
                    delta = float(data.get("quantity") or 0) - float(old["quantity"])
                    if abs(delta) > 1e-9:
                        conn.execute(
                            "INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference_type,reference_id,note,created_at) VALUES(?,?,?,?,?,?,?)",
                            (product_id, "manual_edit", delta, "product", product_id, "تعديل كمية من شاشة المنتجات", now),
                        )
                    self.audit(conn, "update", "product", product_id, name)
                    return product_id
                cur = conn.execute(
                    """INSERT INTO products(barcode,name,category,purchase_price,sale_price,quantity,minimum_stock,unit,expiry_date,created_at,updated_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                    values[:-1] + (now, now),
                )
                new_id = int(cur.lastrowid)
                conn.execute("UPDATE products SET usd_price=?, usd_linked=? WHERE id=?", (usd_price, usd_linked, new_id))
                opening = float(data.get("quantity") or 0)
                if opening:
                    conn.execute(
                        "INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference_type,reference_id,note,created_at) VALUES(?,?,?,?,?,?,?)",
                        (new_id, "opening", opening, "product", new_id, "رصيد افتتاحي", now),
                    )
                self.audit(conn, "create", "product", new_id, name)
                return new_id
            except sqlite3.IntegrityError as exc:
                if "barcode" in str(exc).lower() or "unique" in str(exc).lower():
                    raise ValueError("هذا الباركود مستخدم لمنتج آخر") from exc
                raise

    def deactivate_product(self, product_id: int) -> None:
        with self.connect() as conn:
            conn.execute("UPDATE products SET active=0, updated_at=? WHERE id=?", (self.now(), product_id))
            self.audit(conn, "deactivate", "product", product_id)

    # ---------- Parties ----------
    def list_customers(self, search: str = "") -> list[sqlite3.Row]:
        q = f"%{search.strip()}%"
        with self.connect() as conn:
            return list(conn.execute(
                """SELECT c.*, COALESCE((SELECT SUM(debt_amount) FROM sales s WHERE s.customer_id=c.id AND s.status='completed'),0)
                       - COALESCE((SELECT SUM(amount) FROM customer_payments p WHERE p.customer_id=c.id),0) AS balance
                    FROM customers c
                    WHERE c.name LIKE ? OR c.phone LIKE ?
                    ORDER BY c.name""",
                (q, q),
            ).fetchall())

    def list_suppliers(self, search: str = "") -> list[sqlite3.Row]:
        q = f"%{search.strip()}%"
        with self.connect() as conn:
            return list(conn.execute(
                """SELECT s.*, COALESCE((SELECT SUM(debt_amount) FROM purchases p WHERE p.supplier_id=s.id AND p.status='completed'),0)
                       - COALESCE((SELECT SUM(amount) FROM supplier_payments sp WHERE sp.supplier_id=s.id),0) AS balance
                    FROM suppliers s
                    WHERE s.name LIKE ? OR s.phone LIKE ?
                    ORDER BY s.name""",
                (q, q),
            ).fetchall())

    def add_party(self, kind: str, name: str, phone: str = "", address: str = "", notes: str = "") -> int:
        table = "customers" if kind == "customer" else "suppliers"
        entity = "customer" if kind == "customer" else "supplier"
        if not name.strip():
            raise ValueError("الاسم مطلوب")
        with self.connect() as conn:
            cur = conn.execute(
                f"INSERT INTO {table}(name,phone,address,notes,created_at) VALUES(?,?,?,?,?)",
                (name.strip(), phone.strip(), address.strip(), notes.strip(), self.now()),
            )
            party_id = int(cur.lastrowid)
            self.audit(conn, "create", entity, party_id, name.strip())
            return party_id

    def update_party(self, kind: str, party_id: int, name: str, phone: str = "", address: str = "", notes: str = "") -> None:
        table = "customers" if kind == "customer" else "suppliers"
        entity = "customer" if kind == "customer" else "supplier"
        if not name.strip():
            raise ValueError("الاسم مطلوب")
        with self.connect() as conn:
            conn.execute(f"UPDATE {table} SET name=?,phone=?,address=?,notes=? WHERE id=?", (name.strip(), phone.strip(), address.strip(), notes.strip(), party_id))
            self.audit(conn, "update", entity, party_id, name.strip())

    def record_payment(self, kind: str, party_id: int, amount: float, note: str = "") -> int:
        if amount <= 0:
            raise ValueError("قيمة الدفعة يجب أن تكون أكبر من صفر")
        table = "customer_payments" if kind == "customer" else "supplier_payments"
        column = "customer_id" if kind == "customer" else "supplier_id"
        with self.connect() as conn:
            cur = conn.execute(
                f"INSERT INTO {table}({column},amount,note,created_at) VALUES(?,?,?,?)",
                (party_id, amount, note.strip(), self.now()),
            )
            payment_id = int(cur.lastrowid)
            self.audit(conn, "payment", kind, party_id, f"{amount}")
            return payment_id

    # ---------- Sales ----------
    def _next_invoice_no(self, conn: sqlite3.Connection, table: str, prefix: str) -> str:
        day = datetime.now().strftime("%Y%m%d")
        row = conn.execute(f"SELECT COUNT(*) AS c FROM {table} WHERE date(created_at)=date('now','localtime')").fetchone()
        return f"{prefix}-{day}-{int(row['c']) + 1:04d}"

    def create_sale(self, items: list[dict[str, Any]], customer_id: int | None, discount: float, paid_amount: float, note: str = "") -> SaleResult:
        if not items:
            raise ValueError("الفاتورة فارغة")
        discount = max(float(discount or 0), 0)
        now = self.now()
        with self.connect() as conn:
            normalized: list[dict[str, Any]] = []
            subtotal = 0.0
            for item in items:
                product = conn.execute("SELECT * FROM products WHERE id=? AND active=1", (int(item["product_id"]),)).fetchone()
                if not product:
                    raise ValueError("أحد المنتجات لم يعد موجوداً")
                qty = float(item.get("quantity") or 0)
                if qty <= 0:
                    raise ValueError("الكمية غير صحيحة")
                if float(product["quantity"]) + 1e-9 < qty:
                    raise ValueError(f"المخزون غير كافٍ للمنتج: {product['name']} (المتوفر {product['quantity']})")
                unit_price = float(item.get("unit_price") or product["sale_price"])
                line_total = round(qty * unit_price, 2)
                subtotal += line_total
                normalized.append({
                    "product": product,
                    "quantity": qty,
                    "unit_price": unit_price,
                    "line_total": line_total,
                })
            total = max(round(subtotal - discount, 2), 0)
            paid = min(max(float(paid_amount or 0), 0), total)
            debt = round(total - paid, 2)
            if debt > 0 and not customer_id:
                raise ValueError("يجب اختيار عميل عند تسجيل فاتورة بالدين أو الدفع الجزئي")
            payment_type = "cash" if debt <= 0 else ("debt" if paid <= 0 else "partial")
            invoice_no = self._next_invoice_no(conn, "sales", "S")
            cur = conn.execute(
                """INSERT INTO sales(invoice_no,customer_id,subtotal,discount,total,paid_amount,debt_amount,payment_type,note,status,created_at)
                   VALUES(?,?,?,?,?,?,?,?,?,'completed',?)""",
                (invoice_no, customer_id, subtotal, discount, total, paid, debt, payment_type, note.strip(), now),
            )
            sale_id = int(cur.lastrowid)
            for item in normalized:
                p = item["product"]
                conn.execute(
                    """INSERT INTO sale_items(sale_id,product_id,barcode,product_name,quantity,unit_price,cost_price,line_total)
                       VALUES(?,?,?,?,?,?,?,?)""",
                    (sale_id, p["id"], p["barcode"], p["name"], item["quantity"], item["unit_price"], p["purchase_price"], item["line_total"]),
                )
                conn.execute("UPDATE products SET quantity=quantity-?, updated_at=? WHERE id=?", (item["quantity"], now, p["id"]))
                conn.execute(
                    "INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference_type,reference_id,note,created_at) VALUES(?,?,?,?,?,?,?)",
                    (p["id"], "sale", -item["quantity"], "sale", sale_id, invoice_no, now),
                )
            self.audit(conn, "create", "sale", sale_id, invoice_no)
            return SaleResult(sale_id, invoice_no, total, paid, debt)

    def void_sale(self, sale_id: int, reason: str) -> None:
        with self.connect() as conn:
            sale = conn.execute("SELECT * FROM sales WHERE id=?", (sale_id,)).fetchone()
            if not sale or sale["status"] != "completed":
                raise ValueError("الفاتورة غير موجودة أو ملغاة مسبقاً")
            items = conn.execute("SELECT * FROM sale_items WHERE sale_id=?", (sale_id,)).fetchall()
            now = self.now()
            for item in items:
                conn.execute("UPDATE products SET quantity=quantity+?, updated_at=? WHERE id=?", (item["quantity"], now, item["product_id"]))
                conn.execute(
                    "INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference_type,reference_id,note,created_at) VALUES(?,?,?,?,?,?,?)",
                    (item["product_id"], "sale_void", item["quantity"], "sale", sale_id, reason, now),
                )
            conn.execute("UPDATE sales SET status='voided', note=trim(note || ' | إلغاء: ' || ?) WHERE id=?", (reason, sale_id))
            self.audit(conn, "void", "sale", sale_id, reason)

    def list_sales(self, date_from: str | None = None, date_to: str | None = None, limit: int = 500) -> list[sqlite3.Row]:
        date_from = date_from or "1900-01-01"
        date_to = date_to or "2999-12-31"
        with self.connect() as conn:
            return list(conn.execute(
                """SELECT s.*, COALESCE(c.name,'نقدي') AS customer_name
                   FROM sales s LEFT JOIN customers c ON c.id=s.customer_id
                   WHERE date(s.created_at) BETWEEN date(?) AND date(?)
                   ORDER BY s.id DESC LIMIT ?""",
                (date_from, date_to, limit),
            ).fetchall())

    def sale_items(self, sale_id: int) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return list(conn.execute("SELECT * FROM sale_items WHERE sale_id=? ORDER BY id", (sale_id,)).fetchall())

    # ---------- Purchases ----------
    def create_purchase(self, items: list[dict[str, Any]], supplier_id: int | None, paid_amount: float, note: str = "") -> SaleResult:
        if not items:
            raise ValueError("فاتورة الشراء فارغة")
        now = self.now()
        with self.connect() as conn:
            normalized = []
            total = 0.0
            for item in items:
                product = conn.execute("SELECT * FROM products WHERE id=? AND active=1", (int(item["product_id"]),)).fetchone()
                if not product:
                    raise ValueError("أحد المنتجات غير موجود")
                qty = float(item.get("quantity") or 0)
                cost = float(item.get("unit_cost") or 0)
                if qty <= 0 or cost < 0:
                    raise ValueError("الكمية أو سعر الشراء غير صحيح")
                line = round(qty * cost, 2)
                total += line
                normalized.append({"product": product, "quantity": qty, "unit_cost": cost, "line_total": line})
            paid = min(max(float(paid_amount or 0), 0), total)
            debt = round(total - paid, 2)
            if debt > 0 and not supplier_id:
                raise ValueError("يجب اختيار المورد عند وجود مبلغ متبقٍ")
            invoice_no = self._next_invoice_no(conn, "purchases", "P")
            cur = conn.execute(
                """INSERT INTO purchases(invoice_no,supplier_id,subtotal,total,paid_amount,debt_amount,note,status,created_at)
                   VALUES(?,?,?,?,?,?,?,'completed',?)""",
                (invoice_no, supplier_id, total, total, paid, debt, note.strip(), now),
            )
            purchase_id = int(cur.lastrowid)
            for item in normalized:
                p = item["product"]
                conn.execute(
                    """INSERT INTO purchase_items(purchase_id,product_id,barcode,product_name,quantity,unit_cost,line_total)
                       VALUES(?,?,?,?,?,?,?)""",
                    (purchase_id, p["id"], p["barcode"], p["name"], item["quantity"], item["unit_cost"], item["line_total"]),
                )
                conn.execute(
                    "UPDATE products SET quantity=quantity+?, purchase_price=?, updated_at=? WHERE id=?",
                    (item["quantity"], item["unit_cost"], now, p["id"]),
                )
                conn.execute(
                    "INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference_type,reference_id,note,created_at) VALUES(?,?,?,?,?,?,?)",
                    (p["id"], "purchase", item["quantity"], "purchase", purchase_id, invoice_no, now),
                )
            self.audit(conn, "create", "purchase", purchase_id, invoice_no)
            return SaleResult(purchase_id, invoice_no, total, paid, debt)

    def list_purchases(self, date_from: str | None = None, date_to: str | None = None, limit: int = 500) -> list[sqlite3.Row]:
        date_from = date_from or "1900-01-01"
        date_to = date_to or "2999-12-31"
        with self.connect() as conn:
            return list(conn.execute(
                """SELECT p.*, COALESCE(s.name,'بدون مورد') AS supplier_name
                   FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id
                   WHERE date(p.created_at) BETWEEN date(?) AND date(?)
                   ORDER BY p.id DESC LIMIT ?""",
                (date_from, date_to, limit),
            ).fetchall())

    def purchase_items(self, purchase_id: int) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return list(conn.execute("SELECT * FROM purchase_items WHERE purchase_id=? ORDER BY id", (purchase_id,)).fetchall())

    def void_purchase(self, purchase_id: int, reason: str) -> None:
        with self.connect() as conn:
            purchase = conn.execute("SELECT * FROM purchases WHERE id=?", (purchase_id,)).fetchone()
            if not purchase or purchase["status"] != "completed":
                raise ValueError("فاتورة الشراء غير موجودة أو ملغاة مسبقاً")
            items = conn.execute("SELECT * FROM purchase_items WHERE purchase_id=?", (purchase_id,)).fetchall()
            now = self.now()
            for item in items:
                product = conn.execute("SELECT quantity,name FROM products WHERE id=?", (item["product_id"],)).fetchone()
                if not product:
                    continue
                if float(product["quantity"]) + 1e-9 < float(item["quantity"]):
                    raise ValueError(f"لا يمكن إلغاء الفاتورة لأن مخزون {product['name']} أقل من الكمية المطلوب عكسها")
            for item in items:
                conn.execute("UPDATE products SET quantity=quantity-?, updated_at=? WHERE id=?", (item["quantity"], now, item["product_id"]))
                conn.execute(
                    "INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference_type,reference_id,note,created_at) VALUES(?,?,?,?,?,?,?)",
                    (item["product_id"], "purchase_void", -item["quantity"], "purchase", purchase_id, reason, now),
                )
            conn.execute("UPDATE purchases SET status='voided', note=trim(note || ' | إلغاء: ' || ?) WHERE id=?", (reason, purchase_id))
            self.audit(conn, "void", "purchase", purchase_id, reason)

    def list_stock_movements(self, limit: int = 1000) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return list(conn.execute(
                """SELECT sm.*, p.barcode, p.name AS product_name
                   FROM stock_movements sm JOIN products p ON p.id=sm.product_id
                   ORDER BY sm.id DESC LIMIT ?""", (limit,)
            ).fetchall())

    # ---------- Inventory / expenses ----------
    def inventory_adjust(self, product_id: int, counted_quantity: float, note: str = "") -> float:
        with self.connect() as conn:
            product = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
            if not product:
                raise ValueError("المنتج غير موجود")
            system_qty = float(product["quantity"])
            counted = float(counted_quantity)
            difference = round(counted - system_qty, 6)
            now = self.now()
            cur = conn.execute(
                "INSERT INTO inventory_sessions(product_id,system_quantity,counted_quantity,difference,note,created_at) VALUES(?,?,?,?,?,?)",
                (product_id, system_qty, counted, difference, note.strip(), now),
            )
            session_id = int(cur.lastrowid)
            conn.execute("UPDATE products SET quantity=?, updated_at=? WHERE id=?", (counted, now, product_id))
            conn.execute(
                "INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference_type,reference_id,note,created_at) VALUES(?,?,?,?,?,?,?)",
                (product_id, "inventory", difference, "inventory", session_id, note.strip(), now),
            )
            self.audit(conn, "inventory", "product", product_id, f"{system_qty} -> {counted}")
            return difference

    def list_inventory_sessions(self, limit: int = 300) -> list[sqlite3.Row]:
        with self.connect() as conn:
            return list(conn.execute(
                """SELECT i.*, p.name AS product_name, p.barcode FROM inventory_sessions i
                   JOIN products p ON p.id=i.product_id ORDER BY i.id DESC LIMIT ?""",
                (limit,),
            ).fetchall())

    def add_expense(self, category: str, amount: float, note: str = "") -> int:
        if amount <= 0:
            raise ValueError("قيمة المصروف يجب أن تكون أكبر من صفر")
        with self.connect() as conn:
            cur = conn.execute("INSERT INTO expenses(category,amount,note,created_at) VALUES(?,?,?,?)", (category.strip() or "عام", amount, note.strip(), self.now()))
            expense_id = int(cur.lastrowid)
            self.audit(conn, "create", "expense", expense_id, f"{category}: {amount}")
            return expense_id

    # ---------- Reporting ----------
    def dashboard_stats(self) -> dict[str, float]:
        today = date.today().isoformat()
        month_start = date.today().replace(day=1).isoformat()
        with self.connect() as conn:
            sales_today = conn.execute("SELECT COALESCE(SUM(total),0) v FROM sales WHERE status='completed' AND date(created_at)=date(?)", (today,)).fetchone()["v"]
            paid_today = conn.execute("SELECT COALESCE(SUM(paid_amount),0) v FROM sales WHERE status='completed' AND date(created_at)=date(?)", (today,)).fetchone()["v"]
            month_sales = conn.execute("SELECT COALESCE(SUM(total),0) v FROM sales WHERE status='completed' AND date(created_at)>=date(?)", (month_start,)).fetchone()["v"]
            stock_value = conn.execute("SELECT COALESCE(SUM(quantity*purchase_price),0) v FROM products WHERE active=1").fetchone()["v"]
            shortages = conn.execute("SELECT COUNT(*) v FROM products WHERE active=1 AND quantity<=minimum_stock").fetchone()["v"]
            customer_debt = conn.execute("SELECT COALESCE(SUM(debt_amount),0) - COALESCE((SELECT SUM(amount) FROM customer_payments),0) v FROM sales WHERE status='completed'").fetchone()["v"]
            supplier_debt = conn.execute("SELECT COALESCE(SUM(debt_amount),0) - COALESCE((SELECT SUM(amount) FROM supplier_payments),0) v FROM purchases WHERE status='completed'").fetchone()["v"]
        return {
            "sales_today": float(sales_today or 0),
            "paid_today": float(paid_today or 0),
            "month_sales": float(month_sales or 0),
            "stock_value": float(stock_value or 0),
            "shortages": float(shortages or 0),
            "customer_debt": float(customer_debt or 0),
            "supplier_debt": float(supplier_debt or 0),
        }

    def report_data(self, date_from: str, date_to: str) -> dict[str, Any]:
        with self.connect() as conn:
            summary = conn.execute(
                """SELECT COALESCE(SUM(total),0) sales_total,
                          COALESCE(SUM(paid_amount),0) sales_paid,
                          COALESCE(SUM(debt_amount),0) sales_debt,
                          COALESCE(SUM(discount),0) discounts,
                          COUNT(*) invoice_count
                   FROM sales WHERE status='completed' AND date(created_at) BETWEEN date(?) AND date(?)""",
                (date_from, date_to),
            ).fetchone()
            gross_profit = conn.execute(
                """SELECT COALESCE(SUM((si.unit_price-si.cost_price)*si.quantity),0) profit
                   FROM sale_items si JOIN sales s ON s.id=si.sale_id
                   WHERE s.status='completed' AND date(s.created_at) BETWEEN date(?) AND date(?)""",
                (date_from, date_to),
            ).fetchone()["profit"]
            purchases = conn.execute(
                "SELECT COALESCE(SUM(total),0) total, COALESCE(SUM(paid_amount),0) paid, COALESCE(SUM(debt_amount),0) debt, COUNT(*) count FROM purchases WHERE status='completed' AND date(created_at) BETWEEN date(?) AND date(?)",
                (date_from, date_to),
            ).fetchone()
            expenses = conn.execute(
                "SELECT COALESCE(SUM(amount),0) total, COUNT(*) count FROM expenses WHERE date(created_at) BETWEEN date(?) AND date(?)",
                (date_from, date_to),
            ).fetchone()
            sales_rows = conn.execute(
                """SELECT s.*, COALESCE(c.name,'نقدي') customer_name FROM sales s LEFT JOIN customers c ON c.id=s.customer_id
                   WHERE date(s.created_at) BETWEEN date(?) AND date(?) ORDER BY s.id DESC""",
                (date_from, date_to),
            ).fetchall()
            top_products = conn.execute(
                """SELECT si.product_name, SUM(si.quantity) quantity, SUM(si.line_total) total
                   FROM sale_items si JOIN sales s ON s.id=si.sale_id
                   WHERE s.status='completed' AND date(s.created_at) BETWEEN date(?) AND date(?)
                   GROUP BY si.product_id, si.product_name ORDER BY quantity DESC LIMIT 20""",
                (date_from, date_to),
            ).fetchall()
            low_stock = conn.execute(
                "SELECT * FROM products WHERE active=1 AND quantity<=minimum_stock ORDER BY quantity ASC, name"
            ).fetchall()
            stock = conn.execute("SELECT * FROM products WHERE active=1 ORDER BY name").fetchall()
            customer_debts = conn.execute(
                """SELECT * FROM (
                    SELECT c.name,c.phone,
                    COALESCE((SELECT SUM(debt_amount) FROM sales s WHERE s.customer_id=c.id AND s.status='completed'),0)
                    - COALESCE((SELECT SUM(amount) FROM customer_payments p WHERE p.customer_id=c.id),0) balance
                    FROM customers c
                ) WHERE balance>0 ORDER BY balance DESC"""
            ).fetchall()
            supplier_debts = conn.execute(
                """SELECT * FROM (
                    SELECT s.name,s.phone,
                    COALESCE((SELECT SUM(debt_amount) FROM purchases p WHERE p.supplier_id=s.id AND p.status='completed'),0)
                    - COALESCE((SELECT SUM(amount) FROM supplier_payments sp WHERE sp.supplier_id=s.id),0) balance
                    FROM suppliers s
                ) WHERE balance>0 ORDER BY balance DESC"""
            ).fetchall()
        net_profit = float(gross_profit or 0) - float(expenses["total"] or 0)
        return {
            "summary": dict(summary),
            "gross_profit": float(gross_profit or 0),
            "net_profit": net_profit,
            "purchases": dict(purchases),
            "expenses": dict(expenses),
            "sales": [dict(r) for r in sales_rows],
            "top_products": [dict(r) for r in top_products],
            "low_stock": [dict(r) for r in low_stock],
            "stock": [dict(r) for r in stock],
            "customer_debts": [dict(r) for r in customer_debts],
            "supplier_debts": [dict(r) for r in supplier_debts],
        }

    def customer_statement(self, customer_id: int) -> dict[str, Any]:
        with self.connect() as conn:
            customer = conn.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
            if not customer:
                raise ValueError("العميل غير موجود")
            sales = conn.execute("SELECT * FROM sales WHERE customer_id=? ORDER BY created_at", (customer_id,)).fetchall()
            payments = conn.execute("SELECT * FROM customer_payments WHERE customer_id=? ORDER BY created_at", (customer_id,)).fetchall()
        return {"party": dict(customer), "sales": [dict(r) for r in sales], "payments": [dict(r) for r in payments]}

    def supplier_statement(self, supplier_id: int) -> dict[str, Any]:
        with self.connect() as conn:
            supplier = conn.execute("SELECT * FROM suppliers WHERE id=?", (supplier_id,)).fetchone()
            if not supplier:
                raise ValueError("المورد غير موجود")
            purchases = conn.execute("SELECT * FROM purchases WHERE supplier_id=? ORDER BY created_at", (supplier_id,)).fetchall()
            payments = conn.execute("SELECT * FROM supplier_payments WHERE supplier_id=? ORDER BY created_at", (supplier_id,)).fetchall()
        return {"party": dict(supplier), "purchases": [dict(r) for r in purchases], "payments": [dict(r) for r in payments]}

    def backup_to(self, destination_db: Path) -> None:
        destination_db.parent.mkdir(parents=True, exist_ok=True)
        source = sqlite3.connect(self.path)
        target = sqlite3.connect(destination_db)
        try:
            source.backup(target)
        finally:
            target.close()
            source.close()
