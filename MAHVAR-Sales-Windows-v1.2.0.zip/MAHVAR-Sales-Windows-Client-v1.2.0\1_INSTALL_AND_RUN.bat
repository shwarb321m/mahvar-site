@echo off
chcp 65001 >nul
cd /d "%~dp0"
title MAHVAR Sales - Install and Run
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_MAHVAR_SALES.ps1"
if errorlevel 1 (
  echo.
  echo Installation failed. Send installation_log.txt to technical support.
  pause
  exit /b 1
)
echo.
echo MAHVAR Sales was installed and started successfully.
timeout /t 2 >nul
