@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYFILE=%LOCALAPPDATA%\MAHVARSalesLauncher\python_path.txt"
set "PYTHON="
if exist "%PYFILE%" set /p PYTHON=<"%PYFILE%"
if not defined PYTHON if exist "%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe" set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe"
if not defined PYTHON if exist "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe" set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"
if not defined PYTHON (
  echo Python was not found. Run 1_INSTALL_AND_RUN.bat first.
  pause
  exit /b 1
)
set "PYW=%PYTHON:python.exe=pythonw.exe%"
if exist "%PYW%" set "PYTHON=%PYW%"
start "" /D "%~dp0system" "%PYTHON%" "%~dp0system\server.py"
endlocal
