from __future__ import annotations

import csv
import html
import json
import os
import shutil
import subprocess
import tempfile
import urllib.parse
import webbrowser
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

from database import Database, documents_dir


def money(value: Any, currency: str = "ل.س") -> str:
    try:
        number = float(value or 0)
    except (TypeError, ValueError):
        number = 0
    number = round(number, 2) + 0.0
    text = f"{number:,.2f}".rstrip("0").rstrip(".")
    return f"{text} {currency}"


def safe_filename(text: str) -> str:
    allowed = "-_.() "
    return "".join(c for c in text if c.isalnum() or c in allowed).strip().replace(" ", "_") or "report"


def report_folder() -> Path:
    path = documents_dir() / "MAHVAR Sales Reports"
    path.mkdir(parents=True, exist_ok=True)
    return path


def backup_folder() -> Path:
    path = documents_dir() / "MAHVAR Sales Backups"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _table(headers: list[str], rows: list[list[Any]]) -> str:
    head = "".join(f"<th>{html.escape(str(h))}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{html.escape(str(v))}</td>" for v in row) + "</tr>" for row in rows)
    if not rows:
        body = f'<tr><td colspan="{len(headers)}" class="empty">لا توجد بيانات</td></tr>'
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def build_report_html(db: Database, date_from: str, date_to: str, report_type: str = "full") -> str:
    settings = db.all_settings()
    data = db.report_data(date_from, date_to)
    cur = settings.get("currency", "ل.س")
    store = settings.get("store_name", "MAHVAR للمبيعات")
    summary = data["summary"]
    cards = [
        ("إجمالي المبيعات", money(summary["sales_total"], cur)),
        ("المقبوض", money(summary["sales_paid"], cur)),
        ("مبيعات آجلة", money(summary["sales_debt"], cur)),
        ("عدد الفواتير", str(summary["invoice_count"])),
        ("مجمل الربح", money(data["gross_profit"], cur)),
        ("المصاريف", money(data["expenses"]["total"], cur)),
        ("صافي الربح التقريبي", money(data["net_profit"], cur)),
        ("المشتريات", money(data["purchases"]["total"], cur)),
    ]
    cards_html = "".join(f'<div class="card"><span>{html.escape(k)}</span><strong>{html.escape(v)}</strong></div>' for k, v in cards)

    sales_table = _table(
        ["رقم الفاتورة", "التاريخ", "العميل", "الإجمالي", "المدفوع", "الدين", "الحالة"],
        [[r["invoice_no"], r["created_at"], r["customer_name"], money(r["total"], cur), money(r["paid_amount"], cur), money(r["debt_amount"], cur), "مكتملة" if r["status"] == "completed" else "ملغاة"] for r in data["sales"]],
    )
    top_table = _table(
        ["المنتج", "الكمية المباعة", "قيمة المبيعات"],
        [[r["product_name"], f'{r["quantity"]:g}', money(r["total"], cur)] for r in data["top_products"]],
    )
    low_table = _table(
        ["الباركود", "المنتج", "الموجود", "حد التنبيه", "الوحدة"],
        [[r["barcode"], r["name"], f'{r["quantity"]:g}', f'{r["minimum_stock"]:g}', r["unit"]] for r in data["low_stock"]],
    )
    stock_table = _table(
        ["الباركود", "المنتج", "التصنيف", "الكمية", "سعر الشراء", "سعر البيع", "قيمة المخزون"],
        [[r["barcode"], r["name"], r["category"], f'{r["quantity"]:g}', money(r["purchase_price"], cur), money(r["sale_price"], cur), money(float(r["quantity"]) * float(r["purchase_price"]), cur)] for r in data["stock"]],
    )
    customers_table = _table(
        ["العميل", "الهاتف", "الذمة"],
        [[r["name"], r["phone"], money(r["balance"], cur)] for r in data["customer_debts"]],
    )
    suppliers_table = _table(
        ["المورد", "الهاتف", "المتبقي له"],
        [[r["name"], r["phone"], money(r["balance"], cur)] for r in data["supplier_debts"]],
    )

    sections = []
    if report_type in ("full", "sales"):
        sections += [f"<section><h2>تفاصيل المبيعات</h2>{sales_table}</section>", f"<section><h2>الأكثر مبيعاً</h2>{top_table}</section>"]
    if report_type in ("full", "shortages"):
        sections.append(f"<section><h2>بيان النواقص</h2>{low_table}</section>")
    if report_type in ("full", "stock"):
        sections.append(f"<section><h2>بيان المخزون</h2>{stock_table}</section>")
    if report_type in ("full", "debts"):
        sections += [f"<section><h2>ذمم العملاء</h2>{customers_table}</section>", f"<section><h2>ذمم الموردين</h2>{suppliers_table}</section>"]

    return f"""<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير {html.escape(store)}</title>
<style>
@page{{size:A4;margin:12mm}}*{{box-sizing:border-box}}body{{font-family:'Segoe UI',Tahoma,Arial,sans-serif;color:#1f2937;background:#f5f7fb;margin:0}}.page{{max-width:1100px;margin:auto;background:white;padding:28px}}header{{border-bottom:4px solid #0f766e;padding-bottom:15px;margin-bottom:18px}}h1{{margin:0;color:#0f766e}}.meta{{margin-top:8px;color:#64748b}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0}}.card{{border:1px solid #dbe4ea;border-radius:10px;padding:12px;background:#f8fafc}}.card span{{display:block;color:#64748b;font-size:13px}}.card strong{{font-size:18px;color:#0f172a}}section{{margin:25px 0;page-break-inside:avoid}}h2{{font-size:19px;border-right:5px solid #0f766e;padding-right:10px}}table{{width:100%;border-collapse:collapse;font-size:12px}}th{{background:#0f766e;color:white;padding:8px;border:1px solid #d1d5db}}td{{padding:7px;border:1px solid #d1d5db;text-align:center}}tbody tr:nth-child(even){{background:#f8fafc}}.empty{{color:#64748b;padding:20px}}footer{{margin-top:30px;border-top:1px solid #d1d5db;padding-top:10px;color:#64748b;text-align:center}}@media print{{body{{background:white}}.page{{padding:0}}}}
</style></head><body><div class="page"><header><h1>{html.escape(store)}</h1><div class="meta">التقرير من {html.escape(date_from)} إلى {html.escape(date_to)} — تم الإنشاء {datetime.now().strftime('%Y-%m-%d %H:%M')}</div></header><div class="cards">{cards_html}</div>{''.join(sections)}<footer>تم إنشاء التقرير بواسطة نظام MAHVAR للمبيعات المحلي</footer></div></body></html>"""


def export_report(db: Database, date_from: str, date_to: str, report_type: str = "full") -> dict[str, Path | None]:
    store = safe_filename(db.get_setting("store_name", "MAHVAR"))
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = report_folder() / f"{store}_{report_type}_{date_from}_{date_to}_{stamp}"
    html_path = base.with_suffix(".html")
    html_path.write_text(build_report_html(db, date_from, date_to, report_type), encoding="utf-8")
    pdf_path = html_to_pdf(html_path)
    return {"html": html_path, "pdf": pdf_path}


def export_sales_csv(db: Database, date_from: str, date_to: str) -> Path:
    rows = db.list_sales(date_from, date_to, limit=100000)
    store = safe_filename(db.get_setting("store_name", "MAHVAR"))
    path = report_folder() / f"{store}_sales_{date_from}_{date_to}_{datetime.now().strftime('%H%M%S')}.csv"
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["رقم الفاتورة", "التاريخ", "العميل", "الإجمالي", "المدفوع", "الدين", "نوع الدفع", "الحالة", "ملاحظات"])
        for r in rows:
            writer.writerow([r["invoice_no"], r["created_at"], r["customer_name"], r["total"], r["paid_amount"], r["debt_amount"], r["payment_type"], r["status"], r["note"]])
    return path


def find_edge() -> Path | None:
    candidates = [
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("PROGRAMFILES", "")) / "Microsoft/Edge/Application/msedge.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft/Edge/Application/msedge.exe",
    ]
    return next((p for p in candidates if str(p) and p.exists()), None)


def html_to_pdf(html_path: Path) -> Path | None:
    edge = find_edge()
    if not edge:
        return None
    pdf_path = html_path.with_suffix(".pdf")
    try:
        subprocess.run(
            [str(edge), "--headless", "--disable-gpu", f"--print-to-pdf={pdf_path}", html_path.resolve().as_uri()],
            check=True,
            timeout=45,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return pdf_path if pdf_path.exists() else None
    except Exception:
        return None


def build_whatsapp_summary(db: Database, date_from: str, date_to: str, report_type: str = "full") -> str:
    s = db.all_settings()
    data = db.report_data(date_from, date_to)
    cur = s.get("currency", "ل.س")
    store = s.get("store_name", "MAHVAR للمبيعات")
    summary = data["summary"]
    lines = [
        f"📊 تقرير {store}",
        f"📅 من {date_from} إلى {date_to}",
        "──────────────",
        f"🧾 عدد الفواتير: {summary['invoice_count']}",
        f"💰 إجمالي المبيعات: {money(summary['sales_total'], cur)}",
        f"✅ المقبوض: {money(summary['sales_paid'], cur)}",
        f"📝 مبيعات بالدين: {money(summary['sales_debt'], cur)}",
        f"📦 المشتريات: {money(data['purchases']['total'], cur)}",
        f"📉 المصاريف: {money(data['expenses']['total'], cur)}",
        f"📈 صافي الربح التقريبي: {money(data['net_profit'], cur)}",
        f"⚠️ عدد المواد الناقصة: {len(data['low_stock'])}",
        f"👤 عدد العملاء أصحاب الذمم: {len(data['customer_debts'])}",
    ]
    if data["top_products"]:
        lines.append("──────────────")
        lines.append("🏆 الأكثر مبيعاً:")
        for row in data["top_products"][:5]:
            lines.append(f"• {row['product_name']}: {row['quantity']:g}")
    if report_type == "shortages" or (report_type == "full" and data["low_stock"]):
        lines.append("──────────────")
        lines.append("⚠️ أهم النواقص:")
        for row in data["low_stock"][:12]:
            lines.append(f"• {row['name']}: الموجود {row['quantity']:g} / الحد {row['minimum_stock']:g}")
    lines.append("──────────────")
    lines.append("تم إعداد تقرير تفصيلي كملف PDF لإرفاقه عند الحاجة.")
    return "\n".join(lines)


def normalize_phone(phone: str) -> str:
    digits = "".join(ch for ch in phone if ch.isdigit())
    return digits.lstrip("0") if digits else ""


def open_whatsapp(phone: str, text: str) -> None:
    number = normalize_phone(phone)
    encoded = urllib.parse.quote(text)
    if number:
        webbrowser.open(f"https://wa.me/{number}?text={encoded}")
    else:
        webbrowser.open(f"https://web.whatsapp.com/send?text={encoded}")


def open_path(path: Path) -> None:
    if os.name == "nt":
        os.startfile(str(path))  # type: ignore[attr-defined]
    else:
        webbrowser.open(path.resolve().as_uri())


def show_in_folder(path: Path) -> None:
    if os.name == "nt":
        subprocess.Popen(["explorer", "/select,", str(path)])
    else:
        open_path(path.parent)


def create_backup(db: Database) -> Path:
    folder = backup_folder()
    store = safe_filename(db.get_setting("store_name", "MAHVAR"))
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S_%f")
    zip_path = folder / f"MAHVAR_Backup_{store}_{stamp}.zip"
    with tempfile.TemporaryDirectory() as td:
        temp_db = Path(td) / "rasidi_sales.db"
        db.backup_to(temp_db)
        manifest = {
            "app": "OTS Sales Windows Local",
            "version": "3.3.0",
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "store_name": db.get_setting("store_name", ""),
        }
        manifest_path = Path(td) / "manifest.json"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.write(temp_db, "rasidi_sales.db")
            zf.write(manifest_path, "manifest.json")
    db.set_setting("last_backup_date", datetime.now().date().isoformat())
    return zip_path


def validate_backup(zip_path: Path) -> dict[str, Any]:
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = set(zf.namelist())
        if "rasidi_sales.db" not in names or "manifest.json" not in names:
            raise ValueError("ملف النسخة غير صالح")
        manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
        if manifest.get("app") not in ("OTS Sales Windows Local", "MAHVAR Sales Windows Local"):
            raise ValueError("هذه النسخة ليست تابعة لنظام MAHVAR المحلي")
        return manifest


def restore_backup(db: Database, zip_path: Path) -> Path:
    validate_backup(zip_path)
    safety = create_backup(db)
    with tempfile.TemporaryDirectory() as td:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extract("rasidi_sales.db", td)
        restored = Path(td) / "rasidi_sales.db"
        if not restored.exists() or restored.stat().st_size < 1000:
            raise ValueError("قاعدة البيانات داخل النسخة غير صالحة")
        import sqlite3
        check_conn = sqlite3.connect(restored)
        try:
            result = check_conn.execute("PRAGMA quick_check").fetchone()
            if not result or result[0] != "ok":
                raise ValueError("قاعدة البيانات داخل النسخة تالفة")
        finally:
            check_conn.close()
        for suffix in ("-wal", "-shm"):
            stale = Path(str(db.path) + suffix)
            if stale.exists():
                stale.unlink()
        shutil.copy2(restored, db.path)
    db.init_schema()
    return safety
