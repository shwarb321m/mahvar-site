﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$SystemDir = Join-Path $Root 'system'
$Log = Join-Path $Root 'installation_log.txt'
Start-Transcript -Path $Log -Force | Out-Null

function Find-Python {
    $candidates = @(
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:ProgramFiles\Python311\python.exe",
        "$env:ProgramFiles\Python312\python.exe"
    )
    foreach ($path in $candidates) { if (Test-Path $path) { return $path } }
    $cmd = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($cmd) {
        try {
            $ok = & $cmd.Source -c "import sys; print(sys.version_info >= (3,9))" 2>$null
            if ($ok -eq 'True') { return $cmd.Source }
        } catch {}
    }
    return $null
}

try {
    Write-Host "============================================" -ForegroundColor Cyan
    Write-Host " MAHVAR SALES - SAFE INSTALLATION" -ForegroundColor Cyan
    Write-Host "============================================" -ForegroundColor Cyan

    Write-Host "[1/5] Closing any previous MAHVAR Sales process..."
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
      Where-Object { $_.CommandLine -like '*system\server.py*' -or $_.Name -eq 'MAHVAR-Sales.exe' } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

    $Python = Find-Python
    if (-not $Python) {
        Write-Host "[2/5] Installing Python 3.11 from python.org..."
        $Installer = Join-Path $env:TEMP 'python-3.11.9-amd64.exe'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile $Installer -UseBasicParsing
        $proc = Start-Process -FilePath $Installer -ArgumentList '/quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1' -Wait -PassThru
        if ($proc.ExitCode -ne 0) { throw "Python installation failed. Exit code: $($proc.ExitCode)" }
        $Python = Find-Python
        if (-not $Python) { throw 'Python was installed but could not be located.' }
    } else {
        Write-Host "[2/5] Python found: $Python"
    }

    Write-Host "[3/5] Verifying program files..."
    $Required = @('server.py','database.py','license_service.py','license_config.py','reports.py','ui\index.html','ui\app.js','ui\styles.css')
    foreach ($item in $Required) {
        if (-not (Test-Path (Join-Path $SystemDir $item))) { throw "Missing required file: $item" }
    }
    & $Python -m py_compile (Join-Path $SystemDir 'server.py') (Join-Path $SystemDir 'database.py') (Join-Path $SystemDir 'license_service.py') (Join-Path $SystemDir 'reports.py')
    if ($LASTEXITCODE -ne 0) { throw 'Program source validation failed.' }

    Write-Host "[4/5] Saving the local launcher and desktop shortcut..."
    $ConfigDir = Join-Path $env:LOCALAPPDATA 'MAHVARSalesLauncher'
    New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null
    Set-Content -Path (Join-Path $ConfigDir 'python_path.txt') -Value $Python -Encoding UTF8
    Set-Content -Path (Join-Path $ConfigDir 'install_path.txt') -Value $Root -Encoding UTF8

    $ShortcutPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'MAHVAR للمبيعات.lnk'
    $Shell = New-Object -ComObject WScript.Shell
    $Shortcut = $Shell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = Join-Path $Root '2_START_MAHVAR_SALES.bat'
    $Shortcut.WorkingDirectory = $Root
    $Shortcut.IconLocation = "$env:SystemRoot\System32\shell32.dll,220"
    $Shortcut.Description = 'MAHVAR للمبيعات'
    $Shortcut.Save()

    Write-Host "[5/5] Installation completed successfully." -ForegroundColor Green
    Write-Host "Starting MAHVAR Sales now..."
    Start-Process -FilePath (Join-Path $Root '2_START_MAHVAR_SALES.bat') -WorkingDirectory $Root
    Stop-Transcript | Out-Null
    exit 0
} catch {
    Write-Host "" 
    Write-Host "INSTALLATION FAILED: $($_.Exception.Message)" -ForegroundColor Red
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}
