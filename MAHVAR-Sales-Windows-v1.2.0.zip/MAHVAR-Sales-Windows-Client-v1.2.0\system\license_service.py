from __future__ import annotations

import hashlib
import json
import os
import platform
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from license_config import ACTIVATION_API_URL, APP_TYPE, TRIAL_DAYS, WHATSAPP_NUMBER

LOCAL_SALT = "OST-RASIDI-2026-LOCAL-LICENSE"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def parse_utc(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


class LicenseService:
    def __init__(self, data_dir: Path, app_version: str) -> None:
        self.path = data_dir / f"license_{APP_TYPE.lower()}.json"
        self.app_version = app_version
        self._save_lock = threading.RLock()
        self.data = self._load_or_create()

    def _load_or_create(self) -> dict[str, Any]:
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(raw, dict) and raw.get("install_id"):
                    return raw
            except Exception:
                pass
        now = utc_now()
        data = {
            "install_id": str(uuid.uuid4()),
            "trial_started_at": iso_utc(now),
            "last_seen_at": iso_utc(now),
            "activated": False,
            "activation_id": "",
            "customer_name": "",
            "activated_at": "",
            "token": "",
            "integrity": "",
            "clock_tamper": False,
        }
        self._save(data)
        return data

    def _save(self, data: dict[str, Any] | None = None) -> None:
        # Multiple background/API requests may update the license at the same time.
        # A process-local lock plus a unique temporary name prevents collisions and
        # PermissionError on Windows. os.replace keeps the final write atomic.
        with self._save_lock:
            if data is not None:
                self.data = data
            self.path.parent.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(self.data, ensure_ascii=False, indent=2)
            last_error: OSError | None = None
            for attempt in range(5):
                temp = self.path.with_name(
                    f"{self.path.name}.{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}.tmp"
                )
                try:
                    temp.write_text(payload, encoding="utf-8")
                    os.replace(temp, self.path)
                    return
                except OSError as exc:
                    last_error = exc
                    try:
                        temp.unlink(missing_ok=True)
                    except OSError:
                        pass
                    time.sleep(0.12 * (attempt + 1))
            if last_error is not None:
                raise last_error

    def device_id(self) -> str:
        raw = ""
        if os.name == "nt":
            try:
                import winreg
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                    raw = str(winreg.QueryValueEx(key, "MachineGuid")[0])
            except Exception:
                raw = ""
        if not raw:
            raw = f"{platform.node()}|{uuid.getnode()}|{platform.machine()}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]

    def sync_trial(self) -> None:
        if not ACTIVATION_API_URL.startswith("https://"):
            return
        payload = {
            "action": "trial_status",
            "device_id": self.device_id(),
            "app_type": APP_TYPE,
            "device_name": platform.node(),
            "app_version": self.app_version,
        }
        request = urllib.request.Request(
            ACTIVATION_API_URL,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json; charset=utf-8"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=12) as response:
                result = json.loads(response.read().decode("utf-8"))
            if not result.get("ok") or not result.get("trial_started_at"):
                return
            server_start = parse_utc(str(result["trial_started_at"]))
            local_start = parse_utc(str(self.data.get("trial_started_at")))
            if server_start < local_start:
                self.data["trial_started_at"] = iso_utc(server_start)
                self._save()
        except Exception:
            return

    def _integrity(self, activation_id: str, install_id: str, token: str) -> str:
        payload = f"{activation_id}|{install_id}|{token}|{APP_TYPE}|{LOCAL_SALT}"
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _activation_valid(self) -> bool:
        if not self.data.get("activated"):
            return False
        expected = self._integrity(
            str(self.data.get("activation_id", "")),
            str(self.data.get("install_id", "")),
            str(self.data.get("token", "")),
        )
        return bool(self.data.get("integrity")) and expected == self.data.get("integrity")

    def status(self, update_seen: bool = True) -> dict[str, Any]:
        now = utc_now()
        try:
            last_seen = parse_utc(str(self.data.get("last_seen_at", iso_utc(now))))
            if now < last_seen - timedelta(hours=8):
                self.data["clock_tamper"] = True
        except Exception:
            self.data["clock_tamper"] = True

        if update_seen and now >= parse_utc(str(self.data.get("last_seen_at", iso_utc(now)))):
            self.data["last_seen_at"] = iso_utc(now)
            self._save()

        activated = self._activation_valid()
        trial_start = parse_utc(str(self.data.get("trial_started_at")))
        trial_end = trial_start + timedelta(days=TRIAL_DAYS)
        remaining = max(0, int((trial_end - now).total_seconds()))
        trial_active = remaining > 0 and not self.data.get("clock_tamper", False)
        return {
            "ok": True,
            "activated": activated,
            "trial_active": trial_active,
            "trial_days": TRIAL_DAYS,
            "trial_started_at": iso_utc(trial_start),
            "trial_ends_at": iso_utc(trial_end),
            "remaining_seconds": remaining,
            "expired": not activated and not trial_active,
            "install_id": self.data.get("install_id", ""),
            "customer_name": self.data.get("customer_name", ""),
            "activated_at": self.data.get("activated_at", ""),
            "app_type": APP_TYPE,
            "app_version": self.app_version,
            "whatsapp_number": WHATSAPP_NUMBER,
            "api_configured": ACTIVATION_API_URL.startswith("https://"),
            "clock_tamper": bool(self.data.get("clock_tamper", False)),
            "device_name": platform.node(),
            "device_id": self.device_id(),
        }

    def is_allowed(self) -> bool:
        status = self.status(update_seen=True)
        return bool(status["activated"] or status["trial_active"])

    def activate(self, code: str) -> dict[str, Any]:
        code = "".join(ch for ch in str(code).upper().strip() if ch.isalnum() or ch == "-")
        if len(code) < 8:
            raise ValueError("كود التفعيل غير صحيح")
        if not ACTIVATION_API_URL.startswith("https://"):
            raise ValueError("رابط خادم التفعيل غير مضبوط داخل النسخة")
        payload = {
            "action": "activate",
            "code": code,
            "app_type": APP_TYPE,
            "install_id": self.data["install_id"],
            "device_id": self.device_id(),
            "device_name": platform.node(),
            "app_version": self.app_version,
        }
        request = urllib.request.Request(
            ACTIVATION_API_URL,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json; charset=utf-8"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                result = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                detail = json.loads(exc.read().decode("utf-8"))
                message = detail.get("error") or detail.get("message")
            except Exception:
                message = None
            raise ValueError(message or "رفض خادم التفعيل الطلب") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            raise ValueError("تعذر الاتصال بخادم التفعيل. تحقق من الإنترنت") from exc
        if not result.get("ok"):
            raise ValueError(result.get("error") or "فشل التفعيل")
        license_info = result.get("license") or {}
        activation_id = str(license_info.get("activation_id") or result.get("activation_id") or "")
        token = str(result.get("token") or license_info.get("token") or "")
        if not activation_id or not token:
            raise ValueError("رد التفعيل ناقص")
        self.data.update({
            "activated": True,
            "activation_id": activation_id,
            "customer_name": str(license_info.get("customer_name") or ""),
            "activated_at": str(license_info.get("activated_at") or iso_utc(utc_now())),
            "token": token,
            "integrity": self._integrity(activation_id, self.data["install_id"], token),
            "last_seen_at": iso_utc(utc_now()),
            "clock_tamper": False,
        })
        self._save()
        return self.status(update_seen=False)

    def whatsapp_url(self) -> str:
        status = self.status(update_seen=False)
        message = (
            "مرحبا، أريد تفعيل نظام MAHVAR للمبيعات.\n"
            f"نوع النسخة: {APP_TYPE}\n"
            f"الإصدار: {self.app_version}\n"
            f"رمز التثبيت: {status['install_id']}\n"
            f"اسم الجهاز: {status['device_name']}"
        )
        from urllib.parse import quote
        return f"https://wa.me/{WHATSAPP_NUMBER}?text={quote(message)}"
