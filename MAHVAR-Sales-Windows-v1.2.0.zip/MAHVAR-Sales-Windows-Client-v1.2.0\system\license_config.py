ACTIVATION_API_URL = "https://script.google.com/macros/s/AKfycbwIa1-M-arJey6Nk8BxqcN-VNQ_h_xu_3nKwHy2tv7lWIgE4s0nfLkJLgv49dTLSOyEqw/exec"
WHATSAPP_NUMBER = "963962746115"
APP_TYPE = "WINDOWS_SCANNER"
TRIAL_DAYS = 5
